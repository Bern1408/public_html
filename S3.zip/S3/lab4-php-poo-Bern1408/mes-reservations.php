<?php include_once("inc/header.php"); ?>

<h1 class="center">Vos réservations !</h1>

<?php if(isset($_SESSION['username'])){ ?>

    <?php if(isset($_SESSION['datedebut'])){ ?>    

    <ul class="traitement">
        <li><span>Date de début: </span><?php echo $_SESSION['datedebut']  ?></li>
        <li><span>Date de fin: </span><?php echo $_SESSION['datefin'] ?></li>
        <li><span>Age du locataire: </span><?php echo $_SESSION['age'] ?> </li>
        <li><span>Voiture sélectionnée:
            </span><?php echo $_SESSION['voiture']; ?>
        </li>
    </ul>
    
    <div class="row center">
        <img class="img-reservation" src="img/<?php echo  $_SESSION['voitureimg']; ?>.jpg"
            alt="<?php echo $_SESSION['voiture']; ?>">
    </div>

    <?php } else { ?>
    <h2 class="center">Aucune réservation. <br> <a href="reservation.php">Cliquez ici pour réserver une voiture.</a> </h2>
    <?php } ?>

<?php } else { ?>

<h2 class="center">Vous n'êtes pas connecté. <br> Veuillez ouvrir une session pour réserver une voiture.</h2>

<?php } ?>

<?php include_once("inc/footer.php"); ?>