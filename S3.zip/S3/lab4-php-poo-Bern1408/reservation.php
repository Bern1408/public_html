<?php include_once("inc/header.php"); ?>

<h1 class="center">Réservez votre voiture</h1>

<?php if(isset($_SESSION['username'])){ ?>

<form class="reservation" action="traitement.php" method="post">

    <div class="row">
        <label for="datedebut">Début de location</label>
        <input type="date" name="datedebut" id="datedebut">

        <label for="datefin">Fin de location</label>
        <input type="date" name="datefin" id="datefin">
    </div>

    <div class="row">
        <label for="age">Age du locataire</label>
        <input type="number" name="age" id="age" min="25">
    </div>

    <hr>

    <label for="">Sélectionnez votre voiture</label>
    <div class="row wrap">
    <div class="row select-car col-6">
            <input type="radio" name="voiture" id="vid0" value="spark;Chevrolet Spark">
            <img src="img/spark.jpg" alt=" Chevrolet Spark">
            <h3>Chevrolet Spark </h3>
        </div>
                <div class="row select-car col-6">
            <input type="radio" name="voiture" id="vid1" value="forte;Kia Forte">
            <img src="img/forte.jpg" alt=" Kia Forte">
            <h3>Kia Forte </h3>
        </div>
                <div class="row select-car col-6">
            <input type="radio" name="voiture" id="vid2" value="bmw3;BMW 3">
            <img src="img/bmw3.jpg" alt=" BMW 3">
            <h3>BMW 3 </h3>
        </div>
                <div class="row select-car col-6">
            <input type="radio" name="voiture" id="vid3" value="qashqai;Nissan Qashqai">
            <img src="img/qashqai.jpg" alt=" Nissan Qashqai">
            <h3>Nissan Qashqai </h3>
        </div>
                <div class="row select-car col-6">
            <input type="radio" name="voiture" id="vid4" value="escape;Ford Escape">
            <img src="img/escape.jpg" alt=" Ford Escape">
            <h3>Ford Escape </h3>
        </div>
                <div class="row select-car col-6">
            <input type="radio" name="voiture" id="vid5" value="wrangler;Jeep Wranggler">
            <img src="img/wrangler.jpg" alt=" Jeep Wranggler">
            <h3>Jeep Wranggler </h3>
        </div>
    </div>

    <input type="hidden" name="action" value="reservation">

    <div class="row row-right">
        <button type="submit">Réserver la voiture</button>
    </div>

</form>

<?php } else { ?>

<h2 class="center">Vous n'êtes pas connecté. <br> Veuillez ouvrir une session pour réserver une voiture.</h2>

<?php } ?>

<?php include_once("inc/footer.php"); ?>