<?php include_once("inc/header.php"); ?>

<h1 class="center">Informations reçues !</h1>

<?php if(isset($_REQUEST['action']) && $_REQUEST['action'] == "inscription") { ?>
<ul class="traitement">
    <li>Profil
        <ul>
            <li><span>Prénom: </span><?= $_REQUEST['prenom']; ?></li>
            <li><span>Nom: </span><?= $_REQUEST['nom']; ?></li>
            <li><span>Courriel: </span><?= $_REQUEST['courriel']; ?></li>
            <li><span>Mot de passe: </span><?= $_REQUEST['mdp']; ?></li>
        </ul>
    </li>
    <li>Coordonnées
        <ul>
            <li><span>Pays: </span><?= $_REQUEST['pays']; ?></li>
            <li><span>Adresse: </span><?= $_REQUEST['adresse']; ?></li>
            <li><span>Ville: </span><?= $_REQUEST['ville']; ?></li>
            <li><span>Province: </span><?= $_REQUEST['province']; ?></li>
            <li><span>Code postal: </span><?= $_REQUEST['codePostal']; ?></li>
            <li><span>Type Téléphone: </span><?= $_REQUEST['typeTel']; ?></li>
            <li><span>Téléphone: </span><?= $_REQUEST['tel']; ?></li>
        </ul>
    </li>
    <li>Information conducteur
        <ul>
            <li><span>Pays de délivrance: </span><?= $_REQUEST['paysDelivrance']; ?></li>
            <li><span>Date de naissance: </span><?= $_REQUEST['dateNaissance']; ?></li>
            <li><span>Numéro de permis: </span><?= $_REQUEST['noPermis']; ?></li>
            <li><span>Date d'expiration: </span><?= $_REQUEST['dateExpiration']; ?></li>
        </ul>
    </li>
    <li>Préférence
        <ul>
            <li><span>Infolettre: </span><?= (isset($_REQUEST['infolettre']) ? "Oui" : "Non"); ?></li>
            <li><span>Modalité: </span><?= (isset($_REQUEST['modalite']) ? "Oui" : "Non") ?></li>
        </ul>
    </li>
</ul>

<?php } elseif (isset($_REQUEST['action']) && $_REQUEST['action'] == "connexion"){ ?>

    <h1 class="center">Bienvenue <?php echo $_SESSION['username']; ?> </h1>

<?php } elseif (isset($_REQUEST['action']) && $_REQUEST['action'] == "logout"){  ?>

<h1 class="center">Au revoir !</h1>

<?php } elseif (isset($_REQUEST['action']) && $_REQUEST['action'] == "reservation") { ?>
    
    <?php $_SESSION['reservation'] = array($_REQUEST['datedebut'], $_REQUEST['datefin'], $_REQUEST['age'], $_REQUEST['voiture']); ?>
    
    <h2 class="center">Merci pour votre confiance <?php echo $_SESSION['username'] ?> !</h2>
    <h3 class="center">Votre réservation</h3>

    <ul class="traitement">
        <li><span>Date de début: </span><?php echo $_REQUEST['datedebut']  ?></li>
        <li><span>Date de fin: </span><?php echo $_REQUEST['datefin'] ?></li>
        <li><span>Age du locataire: </span><?php echo $_REQUEST['age'] ?> </li>
        <li><span>Voiture sélectionnée: </span><?php echo explode(";", $_REQUEST['voiture'])[1]; ?></li>
    </ul>

    <?php 
        $_SESSION['datedebut'] = $_REQUEST['datedebut'];
        $_SESSION['datefin'] = $_REQUEST['datefin'];
        $_SESSION['age'] = $_REQUEST['age'];
        $_SESSION['voiture'] = explode(";", $_REQUEST['voiture'])[1];
        $_SESSION['voitureimg'] = explode(";", $_REQUEST['voiture'])[0];
    ?>


    

<?php } ?>

<?php include_once("inc/footer.php"); ?>