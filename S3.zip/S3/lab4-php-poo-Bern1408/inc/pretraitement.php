<?php 

if(session_status() === PHP_SESSION_NONE){
    session_start();
}

if (isset($_REQUEST['action']) && $_REQUEST['action'] == "connexion"){
    $_SESSION['username'] = $_REQUEST['username']; 
    
} elseif (isset($_REQUEST['action']) && $_REQUEST['action'] == "logout"){ 

    $_SESSION = array();
    session_destroy(); 
}
?>