</main>
<footer>
<p>&copy; Sherboo! Foire d'Halloween</p>
</footer>
</body>
</html>