<?php include_once('inc/header.php');?>
<!-- Pour aider au formatage voir la classe CSS card-detail qui devrait contenir les informations d'une friandise -->
<div class="card-detail">

    <?php //if(!isset )?>
    <img src="<?php ?>" alt="">

</div>

<?php include_once('inc/footer.php'); ?>