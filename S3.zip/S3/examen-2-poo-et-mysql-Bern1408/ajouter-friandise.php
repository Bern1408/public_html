<?php include_once('inc/header.php'); ?>

<form method="post" action="ajouter-friandise.php" class="ajouter-friandise-form">
    <label for="nom">Nom de la friandise :</label>
    <input type="text" name="nom" id="nom" required>


    <label for="prix">Prix :</label>
    <input type="number" step="0.01" name="prix" id="prix" required>


    <label for="categorie">Catégorie :</label>
    <select name="categorie" id="categorie" required>
        <option value="">-- Sélectionner --</option>
        
    </select>


    <label for="image">Nom du fichier image :</label>
    <input type="text" name="image" id="image" placeholder="citrouille.jpg">

    <label for="description">Description :</label>
    <textarea name="description" id="description" rows="4"></textarea>    

    <input type="hidden" name="action" value="ajouter">
    <button type="submit">Ajouter la friandise</button>
</form>


<?php include_once('inc/footer.php'); ?>