<?php include_once('inc/header.php'); 

$fManager = new FriandiseManager();
$friandises = $fManager->getFriandises();
$categories = $fManager->getCategories();
?>

<form action="index.php" method="post" class="filtre-form">
    <label for="categorie_id">Catégorie :</label>
    <select name="categorie_id" id="categorie_id">
        <option value="">-- Sélectionner --</option> 
        <?php
            foreach ($categories as $categorie) {
                echo '<option value="' . $categorie['categorie'] . '">' . $categorie['categorie'] . '</option>';
            }
        ?>       
    </select>

    <label for="prixmax">Prix max</label> 
    <input type="number" step="0.01" name="prixmax" id="prixmax">

    <input type="checkbox" name="triPrix" id="triPrix">
    <label for="triPrix">Trier par prix</label>

    <input type="checkbox" name="triCategorie" id="triCategorie">
    <label for="triCategorie">Trier par catégorie</label>

    <input type="hidden" name="action" value="filtrer">
    
    <button type="submit">Filtrer !</button>
</form>


<h2>Nos friandises</h2>
<div class="friandises">
    <!-- Pour aider au formatage voir la classe CSS friandise-card qui devrait contenir les informations d'une friandise -->
    
    <?php if(!isset($_GET['filtrer'])){

        foreach ($friandises as $friandise) { 
            echo '<a href="detail.php" class="friandise-card">
                <img src="img/' . $friandise->get_image() . '" alt="a">
                <h3>' . $friandise->get_nom() . '</h3>
                <p> Catégorie: ' . $friandise->get_categorie() . '</p>
                <p> Prix: ' . $friandise->get_prix() . '$</p>
            </a>';
            
    

        } 
    }?>
</div>

<?php include_once('inc/footer.php'); ?>