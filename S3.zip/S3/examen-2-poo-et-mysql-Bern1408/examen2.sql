CREATE DATABASE IF NOT EXISTS `examendevweb2` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `examendevweb2`;

-- -------------------------------------------------------

CREATE TABLE categories (
id INT AUTO_INCREMENT PRIMARY KEY,
nom VARCHAR(100) NOT NULL
) ENGINE=InnoDB;


CREATE TABLE friandises (
id INT AUTO_INCREMENT PRIMARY KEY,
nom VARCHAR(150) NOT NULL,
prix DECIMAL(5,2) NOT NULL,
categorie_id INT NOT NULL,
image VARCHAR(150) DEFAULT NULL,
description TEXT DEFAULT NULL,
FOREIGN KEY (categorie_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;


INSERT INTO categories (nom) VALUES
('Chocolat'),
('Bonbon'),
('Boisson'),
('Gâteau'),
('Confiserie spéciale');


INSERT INTO friandises (nom, prix, categorie_id, image, description) VALUES
('Doigts de sorcière au chocolat', 3.50, 1, 'doigts.jpg', 'Bâtonnets croquants enrobés de chocolat noir avec une amande en guise d\'ongle de sorcière. Délicieusement effrayant !'), 
('Barre choco hantée', 2.95, 1, 'barre.jpg', 'Barre chocolatée fondante au coeur de caramel et de noisettes, enveloppée d\'un emballage phosphorescent. Une friandise qui hante vos papilles !'), 
('Fantômes en chocolat', 3.20, 1, 'fantomes.jpg', 'Petits chocolats blancs en forme de fantômes, au goût doux et fondant. Parfaits pour hanter les pauses sucrées.'), 
('Dentiers de vampire en gélatine', 2.75, 5, 'dentiers.jpg', 'Bonbons gélifiés rouges et blancs en forme de dentiers de vampire, à la texture moelleuse et fruitée. Attention à la morsure !'), 
('Citrouilles en sucre', 1.50, 5, 'citrouille.jpg', 'Petites citrouilles colorées en sucre dur, sucrées à souhait et parfaites pour décorer vos desserts.'), 
('Souris acidulées', 1.90, 5, 'souris.jpg', 'Bonbons gélifiés en forme de petites souris, au goût citron et framboise ultra acidulé.'), 
('Potion de chauve-souris', 4.25, 3, 'potion.jpg', 'Boisson pétillante violette au goût de raisin mystique, servie dans une bouteille noire décorée d\'ailes de chauve-souris.'), 
('Limonade noire', 3.80, 3, 'limonade.jpg', 'Limonade au charbon actif et au citron, d\'un noir profond. Rafraîchissante et terrifiante à la fois.'), 
('Tartelette sanglante', 2.60, 4, 'tartelette.jpg', 'Petite tartelette sablée garnie d\'une confiture rouge éclatante, semblable à du sang de fraise.'), 
('Cupcake araignée', 3.10, 4, 'cupcake.jpg', 'Petit gâteau au chocolat décoré de pattes de réglisse et d\'un glaçage orange, imitant une araignée effrayante.'),
('Biscuit momie', 2.80, 4, 'momie.jpg', 'Biscuit sablé recouvert de glaçage blanc en bandes, rappelant une momie sortie de sa tombe.'), 
('Bonbons éclairs', 1.75, 2, 'eclairs.jpg', 'Bonbons durs pétillants qui éclatent dans la bouche comme un éclair sucré.'), 
('Réglisse maudite', 2.20, 2, 'reglisse.jpg', 'Bâtonnets de réglisse noire au goût intense, enroulés en spirales ensorcelées.'), 
('Caramel brûlé', 2.40, 2, 'caramel.jpg', 'Caramels fondants au goût légèrement fumé, parfaits pour les amateurs de sensations fortes.'), 
('Sucette squelette', 1.50, 2, 'sucette.jpg', 'Sucettes en forme de têtes de squelette, au goût fruité et acidulé.'), 
('Mendiant nocturne', 3.00, 4, 'mendiant.jpg', 'Disque de chocolat noir garni d\'amandes, de raisins secs et de morceaux de noisettes grillées. Une douceur raffinée.'), 
('Gomme ensorcelée', 1.60, 2, 'gomme.jpg', 'Gommes colorées qui changent de couleur en bouche, aux saveurs de fruits tropicaux magiques.'), 
('Bouteille d\'élixir', 4.00, 3, 'elixir.jpg', 'Boisson gazeuse bleue au goût mystère, dont les bulles scintillent à la lumière. Un élixir digne d\'un alchimiste.'), 
('Bonbon surprise', 1.80, 2, 'surprise.jpg', 'Bonbon à coque dure cachant un coeur explosif de poudre acidulée. Effet garanti !'), 
('Truffe noire', 3.90, 5, 'truffe.jpg', 'Truffe fondante enrobée de cacao noir, au cœur de ganache intense. Une bouchée luxueuse et envoûtante.');