<?php

class Friandise
{
    private $_idFriandise;
    private $_nomFriandise;
    private $_prix;
    private $_categorie;
    private $_image;
    private $_description;

    public function __construct($params = array()){
  
        foreach($params as $k => $v){

            $methodName = "set_" . $k;            
            if(method_exists($this, $methodName)) {
                $this->$methodName($v);
            }   
        }
    }

    public function __serialize(){
        return [
            "idFriandise" => $this->_idFriandise,
            "nomFriandise" => $this->_nomFriandise,
            "prix" => $this->_prix,
            "categorie" => $this->_categorie,
            "image" => $this->_image,
            "description" => $this->_description
        ];
    }

    public function __unserialize($data){
        $this->_idFriandise = $data["idFriandise"];
        $this->_nomFriandise = $data["nomFriandise"];
        $this->_prix = $data["prix"];
        $this->_categorie = $data["categorie"];
        $this->_image = $data["image"];
        $this->_description = $data["reservationArray"]; 
    }

    public function __toString() {
        return "$this->_nomFriandise - $this->_categorie - $this->_prix$ ";
    }
    
    //==========ID FRIANDISE===========//
    public function get_idFriandise() {
        return $this->_idFriandise;
    }
    public function set_idFriandise($_idFriandise) {
        $this->_idFriandise = $_idFriandise;

        return $this;
    }

    //==========NOM===========//
    public function get_nom() {
        return $this->_nomFriandise;
    }
    public function set_nom($_nomFriandise) {
        $this->_nomFriandise = $_nomFriandise;

        return $this;
    }

    //==========PRIX===========//
    public function get_prix() {
        return $this->_prix;
    }
    public function set_prix($_prix) {
        $this->_prix = $_prix;

        return $this;
    }

    //==========CATEGORIE ID===========//
    public function get_categorie() {
        return $this->_categorie;
    }
    public function set_categorie($_categorie) {
        $this->_categorie = $_categorie;

        return $this;
    }

    //==========IMAGE===========//
    public function get_image() {
        return $this->_image;
    }
    public function set_image($_image) {
        $this->_image = $_image;

        return $this;
    }

    //==========DESCRIPTION===========//
    public function get_description() {
        return $this->_description;
    }
    public function set_description($_description) {
        $this->_description = $_description;

        return $this;
    }

    public function getPrixAvecTaxe() {
        $prixTaxe = $this->_prix * 1.149975;

        return $prixTaxe;
    }

};
?>