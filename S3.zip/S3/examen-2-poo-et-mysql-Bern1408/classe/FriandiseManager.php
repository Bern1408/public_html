<?php
  require_once './classe/Friandise.php';

    class FriandiseManager {
        private $bd;

        public function __construct() {
            $this->bd = PDOFactory::getMySQLConnection(); 
        }
    
        public function getFriandises($filterArray = array()) {
            $listeFriandises = array();
            $filterRequest = '';

            if (isset($filterArray['prix']) && isset($filterArray['triPrix'])) {
                if (!empty($filterRequest))
                $filterRequest .= ' AND ';
                
                $filterRequest .= ("prix > :prix OR prix = :prix ");
                $queryArray[':prix'] = $filterArray['prix'];
            }

            if (isset($filterArray['categorie']) && isset($filterArray['triCategorie'])) {
                if (!empty($filterRequest))
                $filterRequest .= ' AND ';
                
                $filterRequest .= "c.categorie_id = :categorie_id";
                $listeFriandises[':categorie_id'] = $filterArray['categorie'];
            }

            if (!empty($filterRequest)){
                $filterRequest =  ' WHERE ' . $filterRequest;
            }

            $requete = $this->bd->query('SELECT f.id AS id, f.nom, f.prix, f.categorie_id, f.image, f.description FROM friandises AS f INNER JOIN categories AS c ON f.categorie_id = c.id' );
            while ($friandise = $requete->fetch(PDO::FETCH_ASSOC)) {
                $listeFriandises[] = new Friandise($friandise);
            }

            return $listeFriandises;
        }

        public function getFriandise($id){

            $requete = $this->bd->query("SELECT * FROM friandises AS f INNER JOIN categories AS c ON c.id = f.categorie_id WHERE f.id='$id'");
            $voiture = new voiture($requete->fetch(PDO::FETCH_ASSOC));

            return $voiture;
        }

        public function getCategories(){
            $categories = $this->bd->query("SELECT nom AS categorie FROM categories ORDER BY nom")->fetchAll();

            return $categories;
        }
    };
?>