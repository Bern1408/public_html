<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableaux PHP</title>
</head>
<body>
    <?php 
    $taille = 8;
    $tb = array(78, 88, 44, 91, 60, 71, 74, 56);


    function printTb($table, $taille) {
        echo $table[0];
        for($i = 1; $i < $taille; $i++) { echo ", $table[$i]"; }
    }
    function moyTb($table, $taille) {
        $moy = 0;
        $cpt = 0;
        echo "Moyenne : ";
        for($i = 0; $i < $taille; $i++) {
            $moy += $table[$i];
            $cpt ++;
        }
        echo $moy = $moy / $cpt;
        return $moy;
    }
    function high60($table, $taille) {
        $cpt = 0;
        for($i = 0; $i < $taille; $i++) {
            if($table[$i] >= 60)
                $cpt ++;
        }
        echo "Nb >= 60 : $cpt";
    }
    function lowMoy($table, $taille, $moy) {
        $cpt = 0;
        for($i = 0; $i < $taille; $i++) {
            if($table[$i] >= $moy)
                $cpt ++;
        }
        echo "Nb >= à la moyenne : $cpt";
    }
    function if60($table, $taille) {
        $cpt = 0;
        echo "Est-ce qu'il y a la note de 60? : ";
        for($i = 0; $i < $taille; $i++) {
            if($table[$i] == 60)
                $cpt ++;
        }
        if($cpt > 0)
            echo "Oui";
        else
            echo "Non";
    }
    function greatTb($table, $taille) {
        $note = 0;
        for($i = 0; $i < $taille; $i++) {
            if($table[$i] >= $note)
                $note = $table[$i];
        }
        echo "Meilleure note : $note";
    }
    function sortC($table, $taille) {
        for($i = 0; $i < $taille; $i++) {
            for($j = 0; $j < $taille - 1; $j++) {
                if($table[$j] > $table[$j + 1]) {
                    $temp[$j] = $table[$j];
                    $table[$j] = $table[$j + 1];
                    $table[$j + 1] = $temp[$j];
                }
            }
        }
        echo "Données triées : ";
        printTb($table, $taille);
    }

    echo "Tableau : ";
    printTb($tb, $taille); ?> <br>
    <?php $moy = moyTb($tb, $taille); ?> <br>
    <?php high60($tb, $taille); ?> <br>
    <?php lowMoy($tb, $taille, $moy); ?> <br>
    <?php if60($tb, $taille); ?> <br>
    <?php greatTb($tb, $taille); ?> <br>
    <?php sortC($tb, $taille); ?>
</body>
</html>