<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boucle for</title>
</head>
<body>
    <?php for($i = 0; $i < 13; $i ++){ ?>
        <table border>
            <?php for($j = 0; $j < 13; $j ++){ ?>
                <tr>
                    <td><?php echo "$i x $j"; ?></td>
                    <td><?php echo $i * $j; ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } ?>
</body>
</html>