function exercice1(){
    let nom = prompt("Quel est votre nom ?");
    alert("Salut " + nom);

    let nb1 = prompt("Quel est le 1er nombre ?");
    let nb2 = prompt("Quel est le 2e nombre ?");

    alert("La somme de " + nb1 + " et " + nb2 + " est : " + (Number(nb1) + Number(nb2)));
}

//exercice1();


function exercice2(){
    const temperatures1 = [15, 20, 22, 18, 25];
    const temperatures2 = {lundi:15, mardi:20, mercredi:22, jeudi:18, vendredi:25};

    
    /*
    console.log("Température avec boucle for");
    for(let i=0; i<temperatures1.length; i++ ){
        console.log(temperatures1[i]);
    }

    console.log("Température avec boucle for in pour affichage d'un array associatif");
    for(temperature in temperatures2){
        console.log(temperature + " il a fait " + temperatures2[temperature]);
    }


    console.log("Température avec boucle for of pour affichage des valeurs");
    for(temperature of temperatures1){
        console.log(temperature);
    }
    */

    //extra cours 2 forEach

    /*
    const nombres = [1, 2, 3, 4, 5];
    let somme = 0;

    nombres.forEach(function(nombre, index, nombres) {
        somme += nombre; 
        console.log(index + " : " + nombre); 
        nombres[index] = somme;
    });

    console.log(`La somme des nombres est : ${somme}`);

    */

}

//let somme = 0;
/*
function(nombre, index, nombres) {
    somme += nombre; 
    //console.log(index + " : " + nombre);

    //nombres[index] = somme;
    //console.log(nombres[index]);
}*/

exercice2();

function exercice3(){

    let nom = document.getElementById("nom");
    alert("Le nom du destinataire est : " + nom.value);

}

document.getElementById("btnEnvoyer").addEventListener('click', exercice3);

function exercice4(evt){
    
    let labels = document.getElementsByTagName("label");
    for(let i=0; i<labels.length; i++){
        
        labels[i].classList.remove("red");
        labels[i].classList.remove("blue");

        if(evt.target.id == 'rouge'){
            labels[i].classList.add("red");
        } else if (evt.target.id == 'bleu'){
            labels[i].classList.add("blue");
        }
        
    }

}

document.getElementById("noir").addEventListener('change', exercice4);
document.getElementById("rouge").addEventListener('change', exercice4);
document.getElementById("bleu").addEventListener('change', exercice4);


//demo Cours2
document.getElementById("form1").addEventListener("submit", dontSendMe);

function dontSendMe(evt){
    let nom = document.getElementById("nom");
    console.log("Le courriel est " + nom.nextElementSibling.nextElementSibling.nextElementSibling.nextElementSibling.value);

    if (nom.value != "Simon"){
        evt.preventDefault();
        evt.target.nextElementSibling.innerHTML += "Désolé tu peux pas l'envoyer tant que ton nom n'est pas Simon...<br/>";
    }
}