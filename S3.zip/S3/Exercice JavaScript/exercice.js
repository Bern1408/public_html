function exercice1() {
    let nom = prompt("Quel est votre nom ?");
    alert("Salut " + nom);
    let nb1 = Number(prompt("Entrez le nombre 1 :"));
    let nb2 = Number(prompt("Entrez le nombre 2 :"));
    let somme = nb1 + nb2;
    alert("La somme de " + nb1 + " et " + nb2 + " est : " + somme);
}

function exercice2() {
    const temperatures1 = [15, 20, 22, 18, 25];
    const temperatures2 = {lundi:15, mardi:20, mercredi:22, jeudi:18, vendredi:25};

    for (let i = 0; i < temperatures1.length; i++) {
        console.log(temperatures1[i]);
    }

    for (temp in temperatures2) {
        console.log(temp + " il a fait " + temperatures2[temp]);
    }

    for (temp of temperatures1) {
        console.log(temp);
    }
}

function exercice3() {
    let nom = document.getElementById("nom");
    alert("Les nom du destinataire est : " + nom.value);
}

document.getElementById('btnEnvoyer').addEventListener('click', exercice3);

function exercice4(evt) {
    //alert(evt.target.id);
    let labels = document.getElementsByTagName('label');
    for(let i = 0; i < labels.length; i++) {
        labels[i].classList.remove('red', 'blue');
        
        if(evt.target.id == 'rouge') {
            labels[i].classList.add('red');
        } else if(evt.target.id == 'bleu') {
            labels[i].classList.add('blue');
        }
    }
}

document.getElementById('labels').addEventListener('change', exercice4);