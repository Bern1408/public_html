//CLASSE LUTIN
class Lutin {
    constructor(nom, poste, statut) {
        this.nom = nom;
        this.poste = poste;
        this.statut = statut;
    }
}

const lutins = [
    new Lutin("Biscuit", "Atelier", "Disponible"),
    new Lutin("Canelle", "Emballage", "En pause"),
    new Lutin("Neige", "Rénovation", "Disponible"),
    new Lutin("Grelot", "Atelier", "Indisponible"),
    new Lutin("Pétale", "Cuisine", "Disponible")
];


//COOKIES
function setCookie(nom, valeur, jours) {
    let d = new Date();
    d.setTime(d.getTime() + (jours * 24 * 60 * 60 * 1000));
    const expire = "expires=" + d.toUTCString();
    document.cookie = nom + "=" + encodeURIComponent(valeur) + ";" + expire + ";path=/";
}

function getCookie(nom) {
    const nomEQ = nom + "=";
    const ca = document.cookie.split(";");
    for (let c of ca) {
        c = c.trim();
        if (c.indexOf(nomEQ) === 0) {
            return decodeURIComponent(c.substring(nomEQ.length));
        }
    }
    return null;
}

//MODE NOEL
document.getElementById("btnNoel").addEventListener("click", changeTheme);

function changeTheme() {
    if(document.body.classList.contains("noel")) {
        document.body.classList.remove('noel');
    }
    else{
        const date = new Date();
        alert(25 - date.getDate() + " jours avant Noël")
        document.body.classList.add('noel');
    }
}

//FILTRER LES LUTINS
document.getElementById("filtre").addEventListener("change", filterLutins);
const tblBody = document.getElementById("tblBody");
let trs = tblBody.getElementsByTagName("tr");
//let tds = document.getElementsByTagName("td");

function filterLutins(evt){
   if(evt.target.value != "Tous"){
        for (let i=0, l = trs.length; i < l; i++) {
            if( lutins[i].statut == evt.target.value){
                trs[i].classList.remove("hide");
            }
            else{
                trs[i].classList.add("hide");
            }
        }
    }
    else {
        for (let i=0, l = trs.length; i < l; i++) {
            trs[i].classList.remove("hide");
        }
    }
//tds[((i-1)*5)+3].textContent
}

//MODIFIER STATUT

let modBtn = document.getElementsByClassName("modButton");
for (let i=0, l = modBtn.length; i < l; i++) {
    modBtn[i].addEventListener("click", modStatut);
}

function modStatut(evt){
    let newStatus = prompt("Entrez le nouveau statut parmi les options: « Disponible », « En pause », « Indisponible » et « Au travail »");
    if(newStatus != ""){
        let tblD = evt.target.parentElement;
        let tblR = tblD.parentElement;
        lutins[tblR.firstElementChild.textContent].statut = newStatus;
        tblD.previousElementSibling.textContent = newStatus;
        
        //ENREGISTRER DANS COOKIE
        const lutinsCookie = JSON.stringify(lutins);
        setCookie("gestionLutins", lutinsCookie , 1);
    }
}

//LIRE COOKIE
readLutinCookie();
function readLutinCookie(evt){
    if (getCookie('gestionLutins') != 'undefined'){
        let lutinsCookie = JSON.parse(getCookie('gestionLutins'));
        for (let i=0, l = lutins.length; i < l; i++) {
            lutins[i].nom = lutinsCookie[i].nom;
            lutins[i].poste = lutinsCookie[i].poste;
            lutins[i].statut = lutinsCookie[i].statut;
            trs[i].lastElementChild.previousElementSibling.textContent = lutinsCookie[i].statut;
        }
    }
}