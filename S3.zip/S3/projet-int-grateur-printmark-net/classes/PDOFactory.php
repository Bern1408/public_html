<?php 
class PDOFactory {
    const MYSQL_SERVER = 'mysql:host=db;dbname=DBImprimantesDB;charset=utf8';
    const MYSQL_LOGIN = 'root';
    const MYSQL_PASSWORD = 'f4q2DG2obVd3I';

    public static function getMySQLConnection() {
        $bdd = new PDO(self::MYSQL_SERVER, self::MYSQL_LOGIN, self::MYSQL_PASSWORD);
        return $bdd;
    }
};
?>