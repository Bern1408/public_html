<?php
class UsersManager {

    private $bd;

    public function __construct() {
        $this->bd = PDOFactory::getMySQLConnection();
    }

    public function getUserByLogin($courriel, $mdp) {
        $result = $this->bd->query("SELECT * FROM TableUtilisateurs
        WHERE courriel_user = '" . $courriel . "' AND mdp_user = '" . $mdp . "';");

        return $result->fetchAll(PDO::FETCH_ASSOC);;
    }


    public function createUser($prenom, $nom, $courriel, $mdp) {
        $result = "INSERT INTO TableUtilisateurs (prenom_user, nom_user, courriel_user, mdp_user) VALUES
        ('" . $prenom . "', '" . $nom . "', '" . $courriel . "', '" . $mdp . "');";

        $this->bd->exec($result);
    }
}
?>