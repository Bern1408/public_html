<?php

class ImprimantesManager {

    private $bd;

    public function __construct() {
        $this->bd = PDOFactory::getMySQLConnection();
    }

    public function getImprimantes() {
        $result = $this->bd->query("SELECT id, modele, nom_marque AS marque, nom_type AS type, garantie, nom_certification AS certification, cap_papier, vitesse_noir, res_noir, res_couleur, vitesse_couleur, rectoverso, prix, img
        FROM TableImprimantes AS i
            INNER JOIN TableMarques AS m ON i.id_marque = m.id_marque 
            INNER JOIN TableTypes AS t ON i.id_type = t.id_type
            INNER JOIN TableConnectivites AS con ON  i.id_connectivite = con.id_connectivite
            LEFT JOIN TableCertifications AS cer ON  i.id_certification = cer.id_certification
            ORDER BY id;");
        $listeImprimantes = $result->fetchAll(PDO::FETCH_ASSOC);

        $returnList = array();
        foreach($listeImprimantes as $i) {
            array_push($returnList, $i);
        }

        return $returnList;
    }

    public function getImprimantesFromID($id) {
        $result = $this->bd->query("SELECT id, modele, nom_marque AS marque, nom_type AS type, garantie, nom_certification AS certification, cap_papier, vitesse_noir, res_noir, res_couleur, vitesse_couleur, rectoverso, prix, img
        FROM TableImprimantes AS i
            INNER JOIN TableMarques AS m ON i.id_marque = m.id_marque 
            INNER JOIN TableTypes AS t ON i.id_type = t.id_type
            INNER JOIN TableConnectivites AS con ON  i.id_connectivite = con.id_connectivite
            LEFT JOIN TableCertifications AS cer ON  i.id_certification = cer.id_certification
            WHERE i.id = " . $id .";");
        $listeImprimantes = $result->fetchAll(PDO::FETCH_ASSOC);

        return $listeImprimantes;
    }

    public function getImprimanteFiltrer($marque, $certification, $type, $cap, $prixMax, $resNoir, $resCouleur, $conn) {

        if($cap == "") { $cap = 0; }
        if($prixMax == "") { $prixMax = 500; }
        $arguments = array();

        $count = 0;
        if($marque != 0) {
            array_push($arguments, "m.id_marque = " . $marque);
            $count++;
        }
        if($type != 0) {
            array_push($arguments, "t.id_type = " . $type);
            $count++;
        }
        if($certification != 0) {
            array_push($arguments, "cer.id_certification = " . $certification);
            $count++;
        }
        if($resNoir != "") {
            array_push($arguments, "res_noir = '" . $resNoir . "'");
            $count++;
        }
        if($resCouleur != "") {
            array_push($arguments, "res_couleur = '" . $resCouleur . "'");
            $count++;
        }
        if($conn != 0) {
            array_push($arguments, "con.id_connectivite = " . $conn);
            $count++;
        }

        $argument = "";
        if($count >= 1) {
            for($i = 0; $i < $count; $i++) {
                $argument = $argument . " AND " . $arguments[$i] . " ";
            }
        }

        $result = $this->bd->query("SELECT id, modele, nom_marque AS marque, nom_type AS type, garantie, nom_certification AS certification, cap_papier, vitesse_noir, res_noir, res_couleur, vitesse_couleur, rectoverso, prix, img
        FROM TableImprimantes AS i
            INNER JOIN TableMarques AS m ON i.id_marque = m.id_marque 
            INNER JOIN TableTypes AS t ON i.id_type = t.id_type
            INNER JOIN TableConnectivites AS con ON  i.id_connectivite = con.id_connectivite
            LEFT JOIN TableCertifications AS cer ON  i.id_certification = cer.id_certification
            WHERE cap_papier >= " . $cap . " AND
            prix <= " . $prixMax .
            $argument .
            " ORDER BY prix;");
        $listeImprimantes = $result->fetchAll(PDO::FETCH_ASSOC);

        return $listeImprimantes;
    }

    public function getMarques() {
        $result = $this->bd->query("SELECT * FROM TableMarques;");
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTypes() {
        $result = $this->bd->query("SELECT * FROM TableTypes;");
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCertifications() {
        $result = $this->bd->query("SELECT * FROM TableCertifications;");
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getConnectivites() {
        $result = $this->bd->query("SELECT * FROM TableConnectivites;");
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }
}

?>