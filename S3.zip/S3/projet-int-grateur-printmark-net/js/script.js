/*COOKIES---------------------------------------------------------*/
function setCookie(nom, valeur, jours) {
    let d = new Date();
    d.setTime(d.getTime() + (jours * 24 * 60 * 60 * 1000));
    const expire = "expires=" + d.toUTCString();
    document.cookie = nom + "=" + encodeURIComponent(valeur) + ";" + expire + ";path=/";
}

function getCookie(nom) {
    const nomEQ = nom + "=";
    const ca = document.cookie.split(";");
    for (let c of ca) {
        c = c.trim();
        if (c.indexOf(nomEQ) === 0) {
            return decodeURIComponent(c.substring(nomEQ.length));
        }
    }
    return null;
}

/*USER CARD---------------------------------------------------------*/
let userCard = document.getElementsByClassName("user_card");
userCard[0].addEventListener("mouseenter",showUserCard);
userCard[0].addEventListener("mouseleave",showUserCard);

function showUserCard(evt) {
   if(evt.target.classList.contains("user_card")){
        if(evt.type == "mouseenter") {
            evt.target.classList.add("show_user_card");
            evt.target.lastElementChild.classList.remove("hide");
        }
        else {
            evt.target.classList.remove("show_user_card");
            evt.target.lastElementChild.classList.add("hide");
        }
    }
}

/*OUVRIR ET FERMER FILTRER (MOBILE)---------------------------------------------------------*/
if(document.getElementById("DropDownChild")) {
    document.getElementById("DropDownChild").classList.remove('hide');
}
if(document.getElementById("DropDownButton")) {
    if(document.documentElement.clientWidth >= 992) {
        document.getElementById("DropDownButton").classList.add('hide');
    } else {
        document.getElementById("DropDownButton").classList.remove('hide');
    }

    document.getElementById("DropDownButton").addEventListener('click', hideFilter);
}

function hideFilter(evt) {
    document.getElementById("DropDownChild").classList.toggle('hide');
    document.getElementById("DropDownButton").classList.toggle("rotate180");
}

/*COOKIES DE FILTRE---------------------------------------------------------*/
document.getElementById("filterBtn").addEventListener('click', makeCookieFiltre);
let filter_options = document.getElementsByClassName("options_filtre");

const filterParam = [];

function makeCookieFiltre(){
    for (var i = 0; i < filter_options.length; i++) {
        filterParam[i] = filter_options[i].value;
    }
    const filtreCookie = JSON.stringify(filterParam);
    setCookie("filtre", filtreCookie , 1);
}

readCookieFiltre();
function readCookieFiltre(){
    if (getCookie('filtre') != 'undefined'){
        let filterCookie = JSON.parse(getCookie('filtre'));
        //alert (filterCookie);
        for (var i=0, l = filter_options.length; i < l; i++) {
            filter_options[i].value = filterCookie[i];
        }
    }
}