<?php
include_once("inc/header.php");
?>
<body>
    <main>
        <?php if(isset($_SESSION['client'])){ ?>

        <?php } else { ?>
            <h2>Vous n'êtes pas connecté. <br> Connectez-vous pour voir vos favoris.</h2>
        <?php } ?>
    </main>
<?php
    include_once("inc/footer.php");
?>