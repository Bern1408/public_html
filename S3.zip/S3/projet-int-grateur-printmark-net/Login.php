<?php include_once("inc/header.php"); ?>

<body class="login">
<main>        
    <h1>Login</h1>
    <form action="traitement.php" method="post" class="form_login">
        <fieldset id="log" class="">
            <legend><h3>Informations générales</h3></legend>            
                <label for="insc-nom" class="">Courriel</label>            
                <input type="text" name="courriel" id="insc-courriel" class="" required>
                <br>
                <label for="insc-nom">Mot de passe</label>            
                <input type="password" name="mdp" id="insc-pass" value="" class="" required>
            </fieldset>         

        <input type="hidden" name="action" value="connection">
        <button type="submit" class="">Se connecter</button>
        <p>Pas de compte? <a href="inscription.php">Créer compte</a></p>
    </form>
   
</main>
<?php include_once("inc/footer.php"); ?>