<?php include_once("inc/header.php"); ?>

<body class="inscrip">
<main>        
    <h1>Inscription</h1>
    <form action="traitement.php" method="post" class="form_inscrip">

        <div>
            <fieldset id="info" class="">
                <legend><h3>Informations générales</h3></legend>
                
                <label for="insc-prenom" class="">Prénom</label>
                <input type="text" name="prenom" id="insc-prenom" class="" required maxlength="50">
                <br>
                <label for="insc-nom" class="">Nom</label>
                <input type="text" name="nom" id="insc-nom" class="" required maxlength="100">
                <br>
                <label for="insc-nom" class="">Courriel</label>            
                <input type="text" name="courriel" id="insc-courriel" class="" required maxlength="100">
                
            </fieldset>
        </div>
        <div>
            <fieldset id="info-secret" class="">
                <legend><h3>Mot de passe</h3></legend>

                <label for="insc-nom">Mot de passe</label>            
                <input type="password" name="mdp" id="insc-pass" value="" class="" required maxlength="50">
                <br>
                <label for="insc-nom">Confirmer</label>                
                <input type="password" name="mdp-confirm" id="insc-pass-confirm" class="" required maxlength="50">
                
            </fieldset>
            
            <input type="hidden" name="action" value="inscription">
            <button type="submit" class="">Créer le compte</button>
        </div>
    </form>
</main>
<?php include_once("inc/footer.php"); ?>