<?php include_once("inc/header.php"); 

$users = new UsersManager();
?>

<body class="Traitement">
    <main>
        <?php
        if(isset($_POST['action'])) {
            if($_POST['action'] == "connection") {
                $user = $users->getUserByLogin($_POST['courriel'], $_POST['mdp']);

                if($user != NULL) {
                    session_unset();
                    session_destroy();
                    
                    session_start();
                    $_SESSION['user'] = $user[0];

                    ?>
                    <p>Bienvenue <?= $user[0]['prenom_user'] . " " . $user[0]['nom_user'] ?> !</p>
                    <p><a href="Imprimantes.php"> Cliquez ici pour commencer à visiter nos imprimantes</a></p>
                    <?php
                } else {
                    ?>
                    <p>L'identifiant ou le mot de passe est incorrecte.</p>
                    <p><a href="Login.php">Veuillez réessayer</a></p>
                    <?php
                }
            }
            if($_POST['action'] == "inscription") {
                if($_POST['mdp'] == $_POST['mdp-confirm']) {
                    $users->createUser($_POST['prenom'], $_POST['nom'], $_POST['courriel'], $_POST['mdp']);
                    ?>
                    <p>Bienvenue <?= $_POST['prenom'] . " " . $_POST['nom'] ?> !</p>
                    <p>Votre compte à été créé ! <a href="Login.php">Cliquez ici pour vous connecter</a></p>
                    <?php
                }
                else {
                    ?>
                    <p>La confirmation du mot de passe n'est pas correct</p>
                    <p><a href="inscription.php">Veuillez réessayer</a></p>
                    <?php
                }
            }
        }
        ?>
    </main>
</body>

<?php include_once("inc/footer.php"); ?>