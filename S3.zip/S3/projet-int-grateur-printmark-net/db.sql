-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Hôte : db
-- Généré le : lun. 15 déc. 2025 à 16:03
-- Version du serveur : 8.0.43
-- Version de PHP : 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `DBImprimantesDB`
--
CREATE DATABASE IF NOT EXISTS `DBImprimantesDB` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `DBImprimantesDB`;

-- --------------------------------------------------------

--
-- Structure de la table `TableCertifications`
--

CREATE TABLE `TableCertifications` (
  `id_certification` int NOT NULL,
  `nom_certification` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `TableCertifications`
--

INSERT INTO `TableCertifications` (`id_certification`, `nom_certification`) VALUES
(1, 'ENERGY STAR'),
(2, 'ENERGY STAR et EPEAT argent');

-- --------------------------------------------------------

--
-- Structure de la table `TableConnectivites`
--

CREATE TABLE `TableConnectivites` (
  `id_connectivite` int NOT NULL,
  `nom_connectivite` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `TableConnectivites`
--

INSERT INTO `TableConnectivites` (`id_connectivite`, `nom_connectivite`) VALUES
(1, 'wifi et USB2.0'),
(2, 'wifi'),
(3, 'sans fil');

-- --------------------------------------------------------

--
-- Structure de la table `TableImprimantes`
--

CREATE TABLE `TableImprimantes` (
  `id` int NOT NULL,
  `id_marque` int NOT NULL,
  `id_certification` int DEFAULT NULL,
  `id_type` int NOT NULL,
  `id_connectivite` int NOT NULL,
  `rectoverso` bit(1) DEFAULT NULL,
  `cap_papier` int NOT NULL,
  `prix` decimal(65,2) DEFAULT NULL,
  `res_couleur` varchar(255) DEFAULT NULL,
  `res_noir` varchar(255) DEFAULT NULL,
  `vitesse_couleur` varchar(255) DEFAULT NULL,
  `vitesse_noir` varchar(255) DEFAULT NULL,
  `garantie` varchar(255) DEFAULT NULL,
  `modele` varchar(255) DEFAULT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `TableImprimantes`
--

INSERT INTO `TableImprimantes` (`id`, `id_marque`, `id_certification`, `id_type`, `id_connectivite`, `rectoverso`, `cap_papier`, `prix`, `res_couleur`, `res_noir`, `vitesse_couleur`, `vitesse_noir`, `garantie`, `modele`, `img`) VALUES
(1, 4, NULL, 1, 1, b'1', 60, 65.49, '4800x1200', '1200x1200', '5.5', '7.5', '1 ans', 'DeskJet 2855e', './img/1.jpg'),
(2, 2, NULL, 1, 2, b'0', 100, 89.99, '4800x1200', '4800x4800', '5.7', '9.9', '1 ans', '0515C023 PIXMA MG3620', './img/2.jpg'),
(3, 2, NULL, 1, 3, b'1', 100, 155.49, '4800x1200', '4800x1200', '10', '15', '0-4 ans', 'Imprimante 4 en 1 sans fil TR7620a', './img/3.jpg'),
(4, 3, 1, 1, 1, b'1', 100, 329.99, '4800x600', '5760x1440', '10', '10', '1-3 ans', 'EcoTank ET-2800', './img/4.jpg'),
(5, 4, NULL, 2, 1, b'1', 150, 355.49, NULL, '600x600', NULL, '30', '1 ans', 'LaserJet MFP M234SDW', './img/5.jpg'),
(6, 3, 1, 1, 1, b'1', 100, 69.99, '4800x1200', '4800x1200', '5.5', '7.5', '1-3 ans', 'Expression Home XP-4200', './img/6.jpg'),
(7, 1, NULL, 1, 1, b'1', 100, 165.49, '4800x1200', '6000x1200', '9', '17', '1 ans', 'MFC-J1012DW', './img/7.jpg'),
(8, 1, 2, 2, 1, b'1', 250, 255.49, '4800x1200', '4800x1200', NULL, '30', '1 ans', 'HL-L2465DW', './img/8.jpg'),
(9, 2, NULL, 1, 2, b'0', 60, 95.94, '4800x1200', '600x600', '4.0', '7.7', '1 ans', 'PIXMA TS3720', './img/9.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `TableMarques`
--

CREATE TABLE `TableMarques` (
  `id_marque` int NOT NULL,
  `nom_marque` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `TableMarques`
--

INSERT INTO `TableMarques` (`id_marque`, `nom_marque`) VALUES
(1, 'Brother'),
(2, 'Canon'),
(3, 'Epson'),
(4, 'HP');

-- --------------------------------------------------------

--
-- Structure de la table `TableTypes`
--

CREATE TABLE `TableTypes` (
  `id_type` int NOT NULL,
  `nom_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `TableTypes`
--

INSERT INTO `TableTypes` (`id_type`, `nom_type`) VALUES
(1, 'Jet d’encre'),
(2, 'Laser');

-- --------------------------------------------------------

--
-- Structure de la table `TableUtilisateurs`
--

CREATE TABLE `TableUtilisateurs` (
  `id_user` int NOT NULL,
  `prenom_user` varchar(20) DEFAULT NULL,
  `nom_user` varchar(255) DEFAULT NULL,
  `courriel_user` varchar(255) DEFAULT NULL,
  `mdp_user` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `TableUtilisateurs`
--

INSERT INTO `TableUtilisateurs` (`id_user`, `prenom_user`, `nom_user`, `courriel_user`, `mdp_user`) VALUES
(1, 'Bob', 'Bricoleur', 'bob@mail.com', 'abc123');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `TableCertifications`
--
ALTER TABLE `TableCertifications`
  ADD PRIMARY KEY (`id_certification`);

--
-- Index pour la table `TableConnectivites`
--
ALTER TABLE `TableConnectivites`
  ADD PRIMARY KEY (`id_connectivite`);

--
-- Index pour la table `TableImprimantes`
--
ALTER TABLE `TableImprimantes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_id_marque` (`id_marque`),
  ADD KEY `FK_id_certification` (`id_certification`),
  ADD KEY `FK_id_type` (`id_type`),
  ADD KEY `FK_id_connectivite` (`id_connectivite`);

--
-- Index pour la table `TableMarques`
--
ALTER TABLE `TableMarques`
  ADD PRIMARY KEY (`id_marque`);

--
-- Index pour la table `TableTypes`
--
ALTER TABLE `TableTypes`
  ADD PRIMARY KEY (`id_type`);

--
-- Index pour la table `TableUtilisateurs`
--
ALTER TABLE `TableUtilisateurs`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `TableCertifications`
--
ALTER TABLE `TableCertifications`
  MODIFY `id_certification` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `TableConnectivites`
--
ALTER TABLE `TableConnectivites`
  MODIFY `id_connectivite` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `TableImprimantes`
--
ALTER TABLE `TableImprimantes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `TableMarques`
--
ALTER TABLE `TableMarques`
  MODIFY `id_marque` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `TableTypes`
--
ALTER TABLE `TableTypes`
  MODIFY `id_type` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `TableUtilisateurs`
--
ALTER TABLE `TableUtilisateurs`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `TableImprimantes`
--
ALTER TABLE `TableImprimantes`
  ADD CONSTRAINT `FK_id_certification` FOREIGN KEY (`id_certification`) REFERENCES `TableCertifications` (`id_certification`),
  ADD CONSTRAINT `FK_id_connectivite` FOREIGN KEY (`id_connectivite`) REFERENCES `TableConnectivites` (`id_connectivite`),
  ADD CONSTRAINT `FK_id_marque` FOREIGN KEY (`id_marque`) REFERENCES `TableMarques` (`id_marque`),
  ADD CONSTRAINT `FK_id_type` FOREIGN KEY (`id_type`) REFERENCES `TableTypes` (`id_type`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
