<?php
include_once("inc/header.php");

$imprimantes = new ImprimantesManager();
$marques = $imprimantes->getMarques();
$certifications = $imprimantes->getCertifications();
$type = $imprimantes->getTypes();
$connectivites = $imprimantes->getConnectivites();

if(isset($_COOKIE['filtre'])){
    $filterCookie = json_decode(stripslashes($_COOKIE['filtre']));

    $imprimantes = $imprimantes->getImprimanteFiltrer($filterCookie[0],$filterCookie[1],$filterCookie[2],$filterCookie[3],$filterCookie[4],$filterCookie[5],$filterCookie[6],$filterCookie[7]);
}
else {
    if(!isset($_POST['Marque'])) {
        $_POST['Marque'] = 0;
    }
    if(!isset($_POST['Certification'])) {
        $_POST['Certification'] = 0;
    }
    if(!isset($_POST['Type'])) {
        $_POST['Type'] = 0;
    }
    if(!isset($_POST['Cap'])) {
        $_POST['Cap'] = "";
    }
    if(!isset($_POST['PrixMax'])) {
        $_POST['PrixMax'] = "";
    }
    if(!isset($_POST['ResNoir'])) {
        $_POST['ResNoir'] = "";
    }
    if(!isset($_POST['ResCouleur'])) {
        $_POST['ResCouleur'] = "";
    }
    if(!isset($_POST['Connectivites'])) {
        $_POST['Connectivites'] = 0;
    }
    $imprimantes = $imprimantes->getImprimanteFiltrer($_POST['Marque'], $_POST['Certification'], $_POST['Type'], $_POST['Cap'], 
    $_POST['PrixMax'], $_POST['ResNoir'], $_POST['ResCouleur'], $_POST['Connectivites']);
}
?>

<body class="Imprimantes">
<main>
<aside class="form">
    <h1>Filtrer</h1>
    <div>
        <form action="Imprimantes.php" method="post">
            <div id="DropDownChild" class="hide">
                <select name="Marque" id="Marque" class="options_filtre">
                    <option value="0" selected>Tous les marques</option>
                    <?php
                    foreach($marques as $m) {
                        ?> <option value="<?= $m['id_marque'] ?>"><?= $m['nom_marque'] ?></option> <?php
                    }
                    ?>
                </select>
                
                <select name="Certification" id="Certification" class="options_filtre">
                    <option value="0" selected>Tous les certifications</option>
                    <?php
                    foreach($certifications as $cer) {
                        ?> <option value="<?= $cer['id_certification'] ?>"><?= $cer['nom_certification'] ?></option> <?php
                    }
                    ?>
                </select>
                
                <select name="Type" id="Type" class="options_filtre">
                    <option value="0" selected>Tous les types</option>
                    <?php
                    foreach($type as $t) {
                        ?> <option value="<?= $t['id_type'] ?>"><?= $t['nom_type'] ?></option> <?php
                    }
                    ?>
                </select>

                <label for="Cap">Capacité de papier : </label>
                <input type="number" name="Cap" id="Cap" placeholder="100" class="options_filtre">
                
                <label for="PrixMax">Prix maximum : </label>
                <input type="number" name="PrixMax" id="PrixMax" placeholder="250" class="options_filtre">
                
                <label for="ResNoir">Résolution en noir : </label>
                <input type="text" name="ResNoir" id="ResNoir" placeholder="4800x1200" class="options_filtre">
                
                <label for="ResCouleur">Résolution en couleur : </label>
                <input type="text" name="ResCouleur" id="ResCouleur" placeholder="1200x1200" class="options_filtre">
                
                <select name="Connectivites" id="Connectivites" class="options_filtre">
                    <option value="0" selected>Tous les connectivités</option>
                    <?php
                        foreach($connectivites as $con) {
                            ?> <option value="<?= $con['id_connectivite'] ?>"><?= $con['nom_connectivite'] ?></option> <?php
                        }
                    ?>
                </select>
                <button type="submit" id="filterBtn">Filtrer</button>
            </div>
            
            <img src="img/dropdown.png" alt="DropDown" id="DropDownButton">
        </form>
    </div>
</aside>
<aside></aside>
<article>
    <?php
    $count = 0;
    foreach($imprimantes as $imp) {
        $count++;
        $path = "Details.php?id=" . $count;
    ?>
    <a href=<?= $path ?> class="carte" >
        <img src=<?= $imp['img']?> alt="image de <?=$imp['modele'] ?>">
        
        <span>
        <p><?= $imp['marque']?> <?=$imp['modele'] ?></p>
        <p><?= $imp['prix'] ?> $</p>
        </span>
    </a>
    <?php
    }
    ?>
</article>
</main>
<?php

include_once("inc/footer.php");
?>