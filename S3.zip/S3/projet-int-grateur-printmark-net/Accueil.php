<?php
include_once("inc/header.php");

$imprimanteManager = new ImprimantesManager();
$imprimantes = $imprimanteManager->getImprimantes();
?>
<body class="accueil">        
    <main class="Accueil">
        <article class="Bienvenus">
            <h1>Bienvenue à printpicker.net</h1>
            <h2>Le site pour trouver l'imprimante de vos rêves !</h2>
        </article>

        <h2>Nos imprimantes</h2>
        <article>
            <?php
            $count = 0;
            for($i = 0; $i < 4; $i++) {
                $count++;
                $path = "Details.php?id=" . $count;
            ?>
            <a href=<?= $path ?> class="carte" >
                <img src=<?= $imprimantes[$i]['img']?> alt="image de <?=$imprimantes[$i]['modele'] ?>">
                
                <span>
                <p><?= $imprimantes[$i]['marque']?> <?=$imprimantes[$i]['modele'] ?></p>
                </span>
            </a>
            <?php
            }
            ?>
        </article>

        <div>
            <a href="Imprimantes.php"><button>Nos imprimantes -></button></a>
        </div>
    </main>
<?php
    include_once("inc/footer.php");
?>