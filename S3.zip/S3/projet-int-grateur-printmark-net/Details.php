<?php
include_once("inc/header.php");

$imprimantes = new ImprimantesManager();
$imprimante = $imprimantes->getImprimantesFromID($_GET['id']);
?>

<body class="Details">
    <main>
        <?php
        if(isset($_GET['id'])) {
            ?>
            <img src=<?= $imprimante[0]['img']?> alt="image de <?=$imprimante[0]['modele'] ?>">
            <div>
                <p>Marque : <?= $imprimante[0]['marque'] ?></p>
                <p>Modèle : <?= $imprimante[0]['modele'] ?></p>
                <p><?= $imprimante[0]['type'] ?></p>
                <p>Garantie : <?= $imprimante[0]['garantie'] ?></p>
                <p>Capacité du bac de papier : <?= $imprimante[0]['cap_papier'] ?> papiers</p>
                <?php if(isset($imprimante[0]['res_noir'])) { ?>
                    <p>Résolution en noir : <?= $imprimante[0]['res_noir'] ?></p>
                <?php }
                if(isset($imprimante[0]['res_noir'])) { ?>
                    <p>Résolution en couleur : <?= $imprimante[0]['res_couleur'] ?></p>
                <?php }
                if(isset($imprimante[0]['certification'])) { ?>
                    <p>Certification : <?= $imprimante[0]['certification'] ?></p>
                <?php }
                if($imprimante[0]['rectoverso'] == "1") { ?>
                    <p>Impression Recto-Verso</p>
                <?php } else {
                    ?>
                    <p>Impression Recto seulement</p>
                    <?php
                }
                ?>
            </div>
            <?php
        }
        ?>
    </main>
</body>

<?php
    include_once("inc/footer.php");
?>