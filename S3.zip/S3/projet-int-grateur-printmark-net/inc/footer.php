</body>
<footer>
<p>Copyrights Alexandre Doe-Langevin, Bernardo Gonçalves da Cruz</p>
</footer>
</html>