<?php
function loadClass($className) {
    require_once './classes/' . $className . '.php';
 }

 spl_autoload_register('loadClass');

session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Printpicker</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@100..900&display=swap" rel="stylesheet">
    <script src="js/script.js" defer></script>
</head>
<header>
    <div>
        <a href="Accueil.php"><img src="img/banner.png" alt="banner" id="banner"></a>
    </div>   
    <div class="user_card">
        <img src="img/account.png" alt="account" id="navi"> 
        <nav class="hide">
            <?php if(isset($_SESSION['user'])){ ?>
                <a href="deconnexion.php">Se déconnecter</a>
            <?php } else { ?>
                <a href="Login.php">Se connecter</a>                    
            <?php } ?>
        </nav>
    </div> 
        <!--

-->
    
</header>