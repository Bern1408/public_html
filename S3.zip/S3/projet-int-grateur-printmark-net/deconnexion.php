<?php include_once("inc/header.php"); 
session_unset();
session_destroy();
?>

<body class="Traitement">
    <main>
        <p>Vous avez été déconnecté ! <a href="Accueil.php">Cliquez ici pour retourner à l'accueil !</a></p>
    </main>
</body>

<?php include_once("inc/footer.php"); ?>