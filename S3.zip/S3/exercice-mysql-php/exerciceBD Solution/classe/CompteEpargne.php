<?php
class CompteEpargne extends CompteBancaire {
    private $tauxInteret;

    //Version avec paramètres classiques
    /*public function __construct($titulaire, $soldeInitial, $tauxInteret) {
        parent::__construct($titulaire, $soldeInitial);
        $this->tauxInteret = $tauxInteret;
    }
    */

    public function __construct($params = array()) {
        foreach($params as $k => $v) {
            $methodName = "set_" . $k; 
            if(method_exists($this, $methodName)) {
                $this->$methodName($v);
            }
        }
    }

    public function appliquerInteret() {
        $interets = $this->get_Solde() * $this->tauxInteret;
        $this->deposer($interets);
    }

    /**
     * Get the value of tauxInteret
     */ 
    public function get_TauxInteret()
    {
        return $this->tauxInteret;
    }

    /**
     * Set the value of tauxInteret
     *
     * @return  self
     */ 
    public function set_TauxInteret($tauxInteret)
    {
        $this->tauxInteret = $tauxInteret;

        return $this;
    }
}