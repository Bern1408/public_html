<?php 
class Banque {
    private static $nbComptes = 0;

    public static function incrementerComptes() {
        self::$nbComptes++;
    }

    public static function getNbComptes() {
        return self::$nbComptes;
    }
}