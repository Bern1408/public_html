<?php 

class CompteBancaireManager {
   private $bd;

   public function __construct() {
      $this->bd = PDOFactory::getMySQLConnection();
   }

   public function getAllComptes() {
      $liste = array();
      $requete = $this->bd->query('SELECT * FROM compte');
      while ($compte = $requete->fetch(PDO::FETCH_ASSOC)) {
         $liste[] = new CompteBancaire($compte);
      }

      return $liste;
   }

   public function getComptesByCriteria($filtre) {
      $where = "";
      $whereArray = array();

      if(isset($filtre['titulaire']) && !empty($filtre['titulaire'])) {
         $where .= " titulaire LIKE :titulaire";
         $whereArray[':titulaire'] = $filtre['titulaire'];
      }

      if(isset($filtre['soldeMin']) && is_numeric($filtre['soldeMin'])) {
         if(!empty($where)) {
            $where .= " AND ";
         }
         $where .= " solde >= :soldeMin";
         $whereArray[':soldeMin'] = $filtre['soldeMin'];
      }

      if(isset($filtre['soldeMax']) && is_numeric($filtre['soldeMax'])) {
         if(!empty($where)) {
            $where .= " AND ";
         }
         $where .= " solde <= :soldeMax";
         $whereArray[':soldeMax'] = $filtre['soldeMax'];
      }

      $requete = $this->bd->prepare('SELECT * FROM compte' .(!empty($where) ? " WHERE " . $where : ""));
      $requete->execute($whereArray);
      $liste = array();
      while ($compte = $requete->fetch(PDO::FETCH_ASSOC)) {
         $liste[] = new CompteBancaire($compte);
      }
      return $liste;
   }

   public function ajouterCompte(CompteBancaire $compte) {
      $requete = $this->bd->prepare('INSERT INTO compte(titulaire, solde, descriptif) VALUES(:titulaire, :solde, :descriptif)');
      $requete->bindValue(':titulaire', $compte->get_Titulaire());
      $requete->bindValue(':solde', $compte->get_Solde());
      $requete->bindValue(':descriptif', $compte->get_Descriptif());
      $retour = $requete->execute();
      return $retour;
   }

   public function modifierCompte(CompteBancaire $compte) {
      $requete = $this->bd->prepare('UPDATE compte SET titulaire = :titulaire, solde = :solde, descriptif = :descriptif WHERE id = :id');
      $requete->bindValue(':titulaire', $compte->get_Titulaire());
      $requete->bindValue(':solde', $compte->get_Solde());
      $requete->bindValue(':descriptif', $compte->get_Descriptif());
      $requete->bindValue(':id', $compte->get_Id(), PDO::PARAM_INT);
      $retour = $requete->execute();
      return $retour;
   }

   public function supprimerCompte(CompteBancaire $compte) {
      $requete = $this->bd->prepare('DELETE FROM compte WHERE id = :id');
      $requete->bindValue(':id', $compte->get_Id(), PDO::PARAM_INT);
      $retour = $requete->execute();
      return $retour;
   }




}