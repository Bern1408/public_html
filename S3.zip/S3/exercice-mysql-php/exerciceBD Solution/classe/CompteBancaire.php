<?php 
class CompteBancaire {
    private $id;
    private $titulaire;
    private $solde;
    private $descriptif;

    //Version avec paramètres classiques
    /*public function __construct($titulaire, $soldeInitial = 0) {
        $this->titulaire = $titulaire;
        $this->solde = $soldeInitial;
        Banque::incrementerComptes();
    }
    */

    //Version plus flexible avec un tableau associatif en paramètre
    public function __construct($params = array()) {
        Banque::incrementerComptes();

        foreach($params as $k => $v) {
            $methodName = "set_" . $k; 
            if(method_exists($this, $methodName)) {
                $this->$methodName($v);
            }
        }
    }

    public function deposer($montant) {
        if ($montant > 0) {
            $this->solde += $montant;
        }
    }

    public function retirer($montant) {
        if ($montant > 0 && $montant <= $this->solde) {
            $this->solde -= $montant;
        } else {
            echo "Retrait impossible pour {$this->titulaire}\n";
        }
    }

    public function __toString() {
        return "Compte de {$this->titulaire}, solde : {$this->solde}\n";
    }

    /**
     * Get the value of titulaire
     */ 
    public function get_Titulaire()
    {
        return $this->titulaire;
    }

    /**
     * Set the value of titulaire
     *
     * @return  self
     */ 
    public function set_Titulaire($titulaire)
    {
        $this->titulaire = $titulaire;

        return $this;
    }

    /**
     * Get the value of solde
     */ 
    public function get_Solde()
    {
        return $this->solde;
    }

    /**
     * Set the value of solde
     *
     * @return  self
     */ 
    public function set_Solde($solde)
    {
        $this->solde = $solde;

        return $this;
    }

    /**
     * Get the value of descriptif
     */ 
    public function get_Descriptif()
    {
        return $this->descriptif;
    }

    /**
     * Set the value of descriptif
     *
     * @return  self
     */ 
    public function set_Descriptif($descriptif)
    {
        $this->descriptif = $descriptif;

        return $this;
    }

    /**
     * Get the value of id
     */ 
    public function get_Id()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function set_Id($id)
    {
        $this->id = $id;

        return $this;
    }
}