<?php

    //Chargement automatique des classes
    function loadClass($className) {
        require_once './classe/' . $className . '.php';  
    }
  
    spl_autoload_register('loadClass');


    $comptesManager = new CompteBancaireManager();

    //Récupération de tous les comptes
    $comptes = $comptesManager->getAllComptes();
    foreach($comptes as $c) {
        echo $c . "<br>";
    }
    echo "---------------------<br>";


    $c1 = new CompteBancaire(array(
        'titulaire' => 'Jean Dupont',
        'solde' => 1500,
        'descriptif' => 'Compte courant'
    ));

    //Ajout d'un compte
    /*if($comptesManager->ajouterCompte($c1)){
        echo "Compte ajouté avec succès<br>";
    } else {
        echo "Erreur lors de l'ajout du compte<br>";
    }*/


    /*
    //Modification du premier compte
    $comptes[0]->set_Solde($comptes[0]->get_Solde() + 500);
    if($comptesManager->modifierCompte($comptes[0])){
        echo "Compte modifié avec succès <br>";
    } else {
        echo "Erreur lors de la modification du compte<br>";
    }
    */

    //Suppression du dernier compte
    /*
    if($comptesManager->supprimerCompte($comptes[count($comptes) - 1])){
        echo "Compte supprimé avec succès <br>";
    } else {
        echo "Erreur lors de la suppression du compte<br>";
    }
    */


    //Récupération des comptes avec des critères
    $filtre = array(
        'soldeMin' => 600,
        'soldeMax' => 2000
    );

    $comptesFiltres = $comptesManager->getComptesByCriteria($filtre);
    foreach($comptesFiltres as $c) {
        echo $c . "<br>";
    }


    

  ?>
