<?php include 'inc/header.php'; ?>
<!--<body>
<main>-->

<?php include 'inc/footer.php'; ?>