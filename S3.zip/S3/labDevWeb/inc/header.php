<?php session_start();?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Bip Bip</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <main>
      <header>
        <div>
          <a href="register.php">Inscription</a>
          <a href="login.php">Se connecter</a>
        </div>

        <nav>
            <a href="index.php">Accueil</a>
            <a href="voitures.php">Les voitures</a>
            <a href="reservations.php">Reserver une voiture</a>
            <a href="mes-reservations.php">Mes réservations</a>
        </nav>

        <img src="img/logo.jpg" alt="Logo">
      </header>