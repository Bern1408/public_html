<?php include 'inc/header.php'; ?>
<!--<body>
<main>-->

<!--
<?php
//if (isset($_POST['prenom'])) {
//    foreach($_POST as $i => $value){
//        echo $i . ": " . $value;
//    }
//} ?>
-->
<h1>Informations reçues !</h1>
<ul> 
    <li>Profil</li>
    <ul>
        <li><strong>Prénom: </strong><?php if(isset($_POST['prenom'])) {echo $_POST['prenom'];}?></li>
        <li><strong>Nom: </strong><?php if(isset($_POST['nom'])) {echo $_POST['nom'];}?></li>
        <li><strong>Courriel: </strong><?php if(isset($_POST['courriel'])) {echo $_POST['courriel'];}?></li>
        <li><strong>Mot de passe: </strong><?php if(isset($_POST['pass'])) {echo $_POST['pass'];}?></li>
    </ul>
    <br>
    <li>Coordonnées</li>
    <ul>
        <li><strong>Pays: </strong><?php if(isset($_POST['pays'])) {echo $_POST['pays'];}?></li>
        <li><strong>Adresse: </strong><?php if(isset($_POST['adresse'])) {echo $_POST['adresse'];}?></li>
        <li><strong>Ville: </strong><?php if(isset($_POST['ville'])) {echo $_POST['ville'];}?></li>
        <li><strong>Province: </strong><?php if(isset($_POST['province'])) {echo $_POST['province'];}?></li>
        <li><strong>Code postal: </strong><?php if(isset($_POST['cp'])) {echo $_POST['cp'];}?></li>
        <li><strong>Type Téléphone: </strong><?php if(isset($_POST['typetel'])) {echo $_POST['typetel'];}?></li>
        <li><strong>Téléphone: </strong><?php if(isset($_POST['tel'])) {echo $_POST['tel'];}?></li>
    </ul>
    <br>
    <li>Information conducteur</li>
    <ul>
        <li><strong>Pays de délivrance: </strong><?php if(isset($_POST['pays-delivrance'])) {echo $_POST['pays-delivrance'];}?></li>
        <li><strong>Date de naissance: </strong><?php if(isset($_POST['ddn'])) {echo $_POST['ddn'];}?></li>
        <li><strong>Numéro de permis: </strong><?php if(isset($_POST['numero-permis'])) {echo $_POST['numero-permis'];}?></li>
        <li><strong>Date d'expiration: </strong><?php if(isset($_POST['dde'])) {echo $_POST['dde'];}?></li>
    </ul>
    <br>
    <li>Préférence</li>
    <ul>
        <li><strong>Infolettre: </strong><?php if(isset($_POST['infolettre'])) {echo "Oui";} else {echo "Non";}?></li>
        <li><strong>Modalité: </strong><?php if(isset($_POST['modalite'])) {echo "Oui";} else {echo "Non";}?></li>
    </ul>
</ul>


<?php include 'inc/footer.php'; ?>