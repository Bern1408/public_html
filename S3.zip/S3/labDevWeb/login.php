<?php include 'inc/header.php'; ?>
<!--<body>
<main>-->

<h1>Entrez votre utilisateur et mot de passe pour accéder aux fonctionnalités</h1>

<form action="traitement.php" method="post" class="login">
    <fieldset class="login">
        <label for="courriel">Nom d'utilisateur: </label>
        <input type="email" name="courriel" id="courriel">

        <label for="pass">Mot de passe: </label>
        <input type="password" name="pass" id="pass">

        <input type="hidden" name="action" value="login">
        <button type="submit">Se connecter</button>
    </fieldset>
</form>

<?php include 'inc/footer.php'; ?>