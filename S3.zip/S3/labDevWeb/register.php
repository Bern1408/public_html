<?php include_once("inc/header.php"); ?>

<h1 class="center">Création de votre compte</h1>

<form action="traitement.php" method="post" class="register">
    <fieldset class="profil">
        <legend>Mon profil</legend>
        <label for="prenom">Prénom: </label>
        <input type="text" name="prenom" id="prenom">

        <label for="nom">Nom: </label>
        <input type="text" name="nom" id="nom">
    
        <label for="courriel">Courriel: </label>
        <input type="email" name="courriel" id="courriel">

        <label for="pass">Mot de passe: </label>
        <input type="password" name="pass" id="pass">
    </fieldset>

    <fieldset class="coord">
        <legend>Coordonnées</legend>

        <label for="pays">Pays: </label>
        <input type="text" name="pays" id="pays">
    
        <label for="adresse">Adresse: </label>
        <input type="text" name="adresse" id="adresse">
    
        <label for="ville">Ville: </label>
        <input type="text" name="ville" id="ville">

        <label for="province">Province: </label>
        <input type="text" name="province" id="province">
    
        <label for="cp">Code postal: </label>
        <input type="text" name="cp" id="cp">
    
        <label for="typetel">Type: </label>
        <select name="typetel" id="typetel">
            <option value="Maison">Maison</option>
            <option value="Mobile">Mobile</option>
            <option value="Bureau">Bureau</option>
            <option value="Autre">Autre</option>
        </select>

        <label for="tel">Téléphone: </label>
        <input type="tel" name="tel" id="tel">
    </fieldset>

    <fieldset class="info-cond">
        <legend>Informations sur le conducteur</legend>

        <label for="pays-delivrance">Pays de délivrance: </label>
        <select name="pays-delivrance" id="pays-delivrance">
            <option value="Canada">Canada</option>
            <option value="États-Unis">États-Unis</option>
            <option value="France">France</option>
        </select>

        <label for="ddn">Date de naissance: </label>
        <input type="date" name="ddn" id="ddn">
    
        <label for="numero-permis">Numéro de permis: </label>
        <input type="text" name="numero-permis" id="numero-permis">

        <label for="dde">Date d'expiration: </label>
        <input type="date" name="dde" id="dde">
    </fieldset>

    <fieldset class="pref">
        <legend>Préférences</legend>
        
        <input type="checkbox" name="infolettre" id="infolettre">
        <label for="infolettre">Je souhaite recevoir les promotion par courriel: </label>
        <span></span>

        <input type="checkbox" name="modalite" id="modalite">
        <label for="modalite">J'accepte les modalités: </label>
        <span></span>

        <span></span>
        <span></span>

        <input type="hidden" name="action" value="inscription">

        <button type="submit">Créer le compte</button>
    </fieldset>

</form>

<?php include_once("inc/footer.php"); ?>