<?php include 'inc/header.php'; ?>
<!--<body>
<main>-->
<h1>Bienvenue sur ce site de location de voiture</h1>
<h2>Nos voitures vous mènerons là où vous le souhaitez avec style !</h2>

<?php include 'inc/footer.php'; ?>