<?php include 'inc/header.php'; ?>

        <h2>Films à l'affiche</h2>

        <div class="films-grid">

            <div class="card featured">
                <img src="images/film1.png" alt="Film 1">
                <div>
                    <h3>Le Voyage Interstellaire</h3>
                    <p>Durée : 2h15</p>
                    <p>Séances : 13h30 | 16h | 20h</p>
                    <a href="panier.php?film=Le Voyage Interstellaire"> Réserver un billet </a>

                </div>
            </div>

            <div class="card c1">
                <img src="images/film2.png" alt="Film 2">
                <div>
                    <h3>Comédie en Folie</h3>
                    <p>Durée : 1h45</p>
                    <p>Séances : 14h | 18h | 21h</p>
                    <a href="panier.php?film=Comédie en Folie"> Réserver un billet </a>
                </div>
            </div>

            <div class="card c2">
                <img src="images/film3.png" alt="Film 3">
                <div>
                    <h3>Horreur Nocturne</h3>
                    <p>Durée : 1h55</p>
                    <p>Séances : 19h | 22h30</p>
                    <a href="panier.php?film=Horreur Nocturne"> Réserver un billet </a>
                </div>
            </div>

            <div class="card c3">
                <img src="images/film4.png" alt="Film 4">
                <div>
                    <h3>Documentaire Nature</h3>
                    <p>Durée : 1h30</p>
                    <p>Séances : 10h | 15h</p>
                    <a href="panier.php?film=Documentaire Nature"> Réserver un billet </a>
                </div>
            </div>

            <div class="card c4">
                <img src="images/film5.png" alt="Film 5">
                <div>
                    <h3>Aventure Médiévale</h3>
                    <p>Durée : 2h05</p>
                    <p>Séances : 11h | 17h | 20h30</p>
                    <a href="panier.php?film=Aventure Médiévale"> Réserver un billet </a>
                </div>
            </div>

        </div>

<?php include 'inc/footer.php'; ?>