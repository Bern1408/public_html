<?php include 'inc/header.php'; ?>

        <!-- La page valide que l'on provient bien du formulaire dans panier.php sinon un message est affiché. -->
        <!-- Le contenu de la page doit afficher un message de confirmation de commande selon le format demandé. -->
        <!-- Si un don a été fait, afficher un message de remerciement pour le don. -->
        <!-- Le panier doit être vidé après la confirmation de la commande. -->
        
        <?php      
        if (isset($_POST["nom"])) { ?>
            <h2>
                <?php echo htmlspecialchars($_POST["nom"]) . ", votre commande a été envoyée " ." !"; ?>
            </h2>
        <?php if (isset($_POST["don"])) { ?>
                <h2>
                    <?php echo "Merci pour votre don de 5$"; ?>
                </h2>
        <?php }
            session_unset();
        }
        else { ?>
            <h2>Veuillez confirmer votre commande via la page <a href="panier.php">panier</a>.</h2>
        <?php } ?>
}

<?php include 'inc/footer.php'; ?>