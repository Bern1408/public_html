    </main>

    <footer class="center">© 2025 Cinéma Étoile</footer>

</body>
</html>