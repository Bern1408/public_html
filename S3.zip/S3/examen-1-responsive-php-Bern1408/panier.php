<?php include 'inc/header.php'; ?>

        <!-- Le contenu de la page doit afficher un message si le panier est vide -->
        <!-- Si un film a été passé en paramètre via l'URL, l'ajouter au panier --> 
        <!-- Si des films sont dans le panier, afficher les films dans le panier et un formulaire pour finaliser la commande -->
          <?php

          if (isset($_GET['film'])) 
          { 
            array_push($panier, $_GET['film']);
            ?>
            
            <h1>Votre panier</h1>

            <table>
              <tr>
                <th>Film dans votre panier</th>          
              </tr>
            <?php for ($i = 0; $i < count($panier); $i++)
            { 
              ?>

              <tr>
                <td>
                <?php echo htmlspecialchars($panier[$i]); ?>         
                </td>                    
              </tr>

            <?php } ?>

            </table>

            <hr>
            
            <h2>Finaliser la commande</h2>
            <form action="checkout.php" method="post">

              <label for="nom">Votre nom :</label>
              <input type="text" name="nom" id="nom" placeholder="Votre nom">

              <label for="email">Votre email :</label>
              <input type="email" name="email" id="email" placeholder="Votre email">

              <span></span>

              
              <span>
                <input type="checkbox" name="don" id="don" value="oui">
                <label for="don">Ajouter un don de 5$ pour soutenir le cinéma?</label>
              </span>

              <input type="hidden" name="action" value="confirmer">
              <span></span>
              
              <input type="submit" value="Confirmer votre commande">
            </form>
          <?php } 
          else { ?>
            <h2>Votre panier est vide!</h2>
          <?php } ?>
          

<?php include 'inc/footer.php'; ?>