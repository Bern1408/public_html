/* Lab 6 */

//Ajout des listener pour le thème
document.getElementById("theme-std").addEventListener("click", changethemeStd);
document.getElementById("theme-sombre").addEventListener("click", changethemeSombre);

// Appelé sur le click du bouton thème standard
function changethemeStd() {
    document.body.classList.remove("sombre");
    setCookie("mode", "std", 30);
}

// Appelé sur le click du bouton thème sombre
function changethemeSombre() {
    document.body.classList.add("sombre");
    setCookie("mode", "sombre", 30);
}

//Fonction qui ajoute ou modifie la valeur d'un cookie
function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    let expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

//Fonction qui lit le cookie demandé 
  function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }


//Si la page demandée est mes-réservations.php
if (document.URL.includes("mes-reservations.php")) {

    //Ajout des listener pour les boutons annuler une réservation
    elems = document.getElementsByClassName("btn-annuler");

    for (let i=0, l = elems.length; i < l; i++) {
        elems[i].addEventListener('click', annuleReservation);
    }


    //Ajout des listener pour les boutons pour voir la description
    elems = document.getElementsByClassName("show-desc");

    for (let i=0, l = elems.length; i < l; i++) {
        elems[i].addEventListener('click', showDesc);
    }

    // Appelé sur le click d'un bouton Annuler cette réservation 
    function annuleReservation(evt){
        if (!confirm('Êtes-vous certain de vouloir annuler cette réservation ?')) { 
            evt.preventDefault();
        }
    }

    // Appelé sur le click d'un bouton "Voir la description"   
    function showDesc(evt){
        if (evt.target.nextElementSibling.classList.contains("hide")){
            evt.target.innerHTML = "Cacher description";
        } else {
            evt.target.innerHTML = "Voir la description";
        }

        evt.target.nextElementSibling.classList.toggle("hide");  
    }

}

/* Lab 7 */

// listener pour les flèches (carrieres.php)
let arrows = document.getElementsByTagName("i");
for (let i=0, l = arrows.length; i < l; i++) {
    arrows[i].addEventListener("click", changePage);
}

//fonction qui change les pages (carrieres.php)
let fieldsets = document.getElementsByTagName("fieldset");
function changePage(evt) {
    for (let i=0, l = fieldsets.length; i < l; i++) {
        fieldsets[i].classList.add("hide");
    }
    
    if(evt.target.id == 'prev-1') {
        fieldsets[0].classList.remove("hide");
    }
    else if(evt.target.id == 'next-1' || evt.target.id == 'prev-2') {
        fieldsets[1].classList.remove("hide");
        bonjour();
    }
    else if(evt.target.id == 'next-2' || evt.target.id == 'prev-3') {
        fieldsets[2].classList.remove("hide");
    }
    else if(evt.target.id == 'next-3') {
        fieldsets[3].classList.remove("hide");
    }
}

// premier panneau (carrieres.php)
let inputs = document.getElementsByTagName("input");
inputs[0].addEventListener("input", bonjour);
inputs[1].addEventListener("input", bonjour);


function bonjour() {
    if(inputs[0].value !='' || inputs[1].value !=''){ 
        document.getElementById('bonjour').classList.remove("hide");
        document.getElementById('nom-prenom').textContent = inputs[0].value + " " + inputs[1].value;
        document.getElementById('nom-bonjour').textContent = inputs[0].value + " " + inputs[1].value;
    }
    else {
        document.getElementById('bonjour').classList.add("hide");
    }
}

// deuxième panneau (carrieres.php)
document.getElementById("poste").addEventListener("change", showPost);

function showPost(evt) {
    let posts = document.getElementsByClassName("desc-poste");
    for (let i=0, l = posts.length; i < l; i++) {
        posts[i].classList.add("hide");
    }

    if(evt.target.value == 'Frontend'){ 
        posts[0].classList.remove("hide");
    }
    else if (evt.target.value == 'Backend'){
        posts[1].classList.remove("hide");
    }
    else if (evt.target.value == 'Gestion'){
        posts[2].classList.remove("hide");
    }
    else if (evt.target.value == 'Autre'){
        posts[3].classList.remove("hide");
    }
}

// listener pour les cases de dispo (carrieres.php)
let dispos = document.getElementsByClassName("plage-dispo");
for (let i=0, l = dispos.length; i < l; i++) {
    dispos[i].addEventListener("click", markDispo);
}
for (let i=0, l = dispos.length; i < l; i++) {
    dispos[i].addEventListener("mouseenter",askDispo);
}
for (let i=0, l = dispos.length; i < l; i++) {
    dispos[i].addEventListener("mouseleave",askDispo);
}
document.addEventListener("keyup", markDispo);

function markDispo(evt) {
    if(evt.type == "click") {
        if (evt.target.classList.contains("preview")){
            evt.target.classList.remove("preview");
            evt.target.classList.add("oui");
            evt.target.textContent = "Oui";
        }
        else if (evt.target.classList.contains("oui")){
            evt.target.classList.remove("oui");
            evt.target.classList.add("preview");
            evt.target.textContent = "Dispo ?";
        }
    }
    else if(!(fieldsets[2].classList.contains("hide"))){
        if (evt.key == "r"){
            for (let i=0, l = dispos.length; i < l; i++) {
                dispos[i].classList.remove("oui");
                dispos[i].classList.add("preview");
                dispos[i].textContent = "";
            }
        }
        else if(evt.key = "v"){
            for (let i=0, l = dispos.length; i < l; i++) {
                dispos[i].classList.remove("preview");
                dispos[i].classList.add("oui");
                dispos[i].textContent = "Oui";
            }
        }
    }
}

function askDispo(evt) {
    if(evt.type == "mouseenter") {
        if (evt.target.classList.contains("preview")){
            evt.target.textContent = "Dispo ?";
        }
    }
    else {
        if (evt.target.classList.contains("preview")){
            evt.target.textContent = "";
        }
    }
}