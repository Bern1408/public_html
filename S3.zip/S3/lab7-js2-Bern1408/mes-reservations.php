<?php include_once("inc/header.php"); ?>

<h1 class="center">Vos réservations !</h1>

<?php if(isset($_SESSION['client'])){ ?>

    <?php 
        $client = unserialize($_SESSION['client']); 
        $rm = new ReservationManager();
        $reservationArrActuel = $rm->getReservationClient($client->get_idClient(), true);
        $reservationArrPassee = $rm->getReservationClient($client->get_idClient(), false);
    ?>

    <?php if(count($reservationArrActuel) || count($reservationArrPassee)){ ?>
        <h2> À venir </h2>
        <?php
        foreach($reservationArrActuel as $reservation) {
            $voiture = $reservation->get_voiture(); ?>
            <div class="row">
                <div class="col-6">
                    <ul class="traitement">
                        <li><span>Date de début: </span><?= $reservation->get_datedebut()->format('Y-m-d')  ?></li>
                        <li><span>Date de fin: </span><?= $reservation->get_dateFin()->format('Y-m-d'); ?></li>
                        <li><span>Age du locataire: </span><?= $reservation->get_ageLocataire(); ?> </li>
                        <li><span>Voiture sélectionnée:</span><?= $voiture->get_marque() . " " . $voiture->get_modele(); ?></li>
                    </ul>
                    <a href="traitement.php?action=delReservation&idReservation=<?= $reservation->get_idReservation(); ?>" class="button btn-annuler">
                        Annuler cette réservation
                    </a>
                    <button class="show-desc style-a center">Voir la description</button>
                    <div class="desc hide"><?= $voiture->get_description(); ?></div>
                </div>
                
                <div class="col-6">
                    <img class="img-reservation" src="img/<?= $voiture->get_image(); ?>" alt="<?= $voiture->get_marque() . " " . $voiture->get_modele(); ?>">
                </div>
            </div>
        <?php } ?>

        
        <h2> Historique des réservations </h2>
        <?php
        foreach($reservationArrPassee as $reservation) {
            $voiture = $reservation->get_voiture(); ?>
            <div class="row">
                <div class="col-6">
                    <ul class="traitement">
                        <li><span>Date de début: </span><?= $reservation->get_datedebut()->format('Y-m-d')  ?></li>
                        <li><span>Date de fin: </span><?= $reservation->get_dateFin()->format('Y-m-d'); ?></li>
                        <li><span>Age du locataire: </span><?= $reservation->get_ageLocataire(); ?> </li>
                        <li><span>Voiture sélectionnée:</span><?= $voiture->get_marque() . " " . $voiture->get_modele(); ?></li>
                    </ul>
                 
                </div>
                
                <div class="col-6">
                    <img class="img-reservation" src="img/<?= $voiture->get_image(); ?>" alt="<?= $voiture->get_marque() . " " . $voiture->get_modele(); ?>">
                </div>
            </div>
        <?php } ?>

    <?php } else { ?>
        <h2 class="center">Aucune réservation. <br> <a href="reservation.php">Cliquez ici pour réserver une voiture.</a> </h2>
    <?php } ?>

<?php } else { ?>

    <h2 class="center">Vous n'êtes pas connecté. <br> Veuillez ouvrir une session pour réserver une voiture.</h2>

<?php } ?>

<?php include_once("inc/footer.php"); ?>