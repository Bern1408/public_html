
</main>

<footer class="center">copyright Simon Guimond Dufour
    <span class="right">Thème: 
        <button id="theme-std">Standard</button>
        <button id="theme-sombre">Sombre</button>
    </span>
</footer>
</body>
</html>