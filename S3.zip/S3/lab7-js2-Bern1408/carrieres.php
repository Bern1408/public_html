<?php include_once("inc/header.php"); ?>


<h1 class="center">Rejoins notre équipe !</h1>

<form action="traitement.php" method="post" class="frm-carrière">
    <fieldset id="contact">
        <legend>Faisons connaissance !</legend>
        <div class="row">
            <span class="vide"></span>
            <div class="grid-2col">
                <label for="prenom">Prénom: </label>
                <input type="text" name="prenom" id="emp-prenom">

                <label for="nom">Nom: </label>
                <input type="text" name="nom" id="emp-nom">
                    
                <label for="courriel">Courriel: </label>
                <input type="email" name="courriel" id="emp-courriel">

                <span class="hide bonjour" id="bonjour">Bonjour : <span id="nom-prenom"></span></span>

            </div>        
            <i class="fa fa-chevron-circle-right fa-5" aria-hidden="true" id="next-1"></i>
        </div>

    </fieldset>

    <fieldset id="poste-intéret" class="hide">
        <legend>Quel poste t'intéresse ?</legend>
        <div class="row">
            <i class="fa fa-chevron-circle-left fa-5" aria-hidden="true"id="prev-1"></i>
            <div class="grid-2col">
                
                <span class="hide bonjour" id="bonjour">Bonjour : <span id="nom-bonjour"></span></span>

                <label for="poste">Quel poste vous intéresse: </label>
                <select name="poste" id="poste">
                    <option value="Frontend">Frontend</option>
                    <option value="Backend">Backend</option>
                    <option value="Gestion">Gestion de projet</option>
                    <option value="Autre">Autre</option>
                </select>

                <span class="vide"><br></span><span class="vide"></span>

                <span>Description du poste : </span>
                <span class="vide"></span>
                
                <div class="desc-poste" id="Frontend">
                <b>Frontend</b>
                    <p>
                        Notre équipe de développeur Frontend s'occupe d'intégrer des interfaces intuitives pour les utilisateurs.
                    </p>
                </div>

                <div class="desc-poste hide" id="Backend">
                    <b>Backend</b>
                    <p>
                        Notre équipe de développeur Backend s'occupe de programmer les systèmes qui alimentent notre plateforme Web.
                    </p>
                </div>

                <div class="desc-poste hide" id="Gestion">
                    <b>Gestion de projet</b>
                    <p>
                        Pour qu'un projet arrive à bon port il doit être bien géré ! Intégrez notre équipe de gestionnaire de projet et contribuez au succès de l'entreprise.
                    </p>
                </div>

                <div class="desc-poste hide" id="Autre">
                    <b>Autres</b>
                    <p>
                        Nous sommes toujours à la recherche de talents diversifiés.
                    </p>
                        
                </div>
            </div>
            <i class="fa fa-chevron-circle-right fa-5" aria-hidden="true"  id="next-2"></i>
        </div>
    </fieldset>

    <fieldset id="disponibilité" class="hide">
        <legend>Super ! Quand es-tu disponible pour nous rencontrer ?</legend>

        <div class="row">
            <i class="fa fa-chevron-circle-left fa-5" aria-hidden="true"id="prev-2"></i>
            <div class="">
                <p>Clique sur les plages où tu es disponible pour une entrevue</p>

                <table>
                    <tr>
                        <th></th>
                        <th>Lun</th>
                        <th>Mar</th>
                        <th>Mer</th>
                        <th>Jeu</th>
                        <th>Ven</th>
                    </tr>
                    <tr>
                        <th>AM</th>
                        <td class="plage-dispo preview"></td>
                        <td class="plage-dispo preview"></td>
                        <td class="plage-dispo preview"></td>
                        <td class="plage-dispo preview"></td>
                        <td class="plage-dispo preview"></td>
                    </tr>
                    <tr>
                        <th>PM</th>
                        <td class="plage-dispo preview"></td>
                        <td class="plage-dispo preview"></td>
                        <td class="plage-dispo preview"></td>
                        <td class="plage-dispo preview"></td>
                        <td class="plage-dispo preview"></td>
                    </tr>
                </table>

                <p class="small">Astuce: appuie sur la touche "r" pour réinitialiser toutes les disponibilités ou sur la touche "v" pour tout sélectionner.</p>
                <p class="nbre">Nombre de plages sélectionnées: <span id="nbre-plages">0</span></p>

            </div>
            <i class="fa fa-chevron-circle-right fa-5" aria-hidden="true"  id="next-3"></i>
        </div>
    </fieldset>

    <fieldset id="antécédent" class="hide">
        <legend>Quels sont tes emplois antérieurs ?</legend>
        <div class="row">
            <i class="fa fa-chevron-circle-left fa-5" aria-hidden="true" id="prev-3"></i>
            <div class="grid-2col">

                <label for="ant-entreprise">Entreprise: </label>    
                <input type="text" name="ant-entreprise" id="ant-entreprise">
                
                <label for="ant-poste">Poste: </label>
                <input type="text" name="ant-poste" id="ant-poste">

                <label for="ant-duree">Durée de l'emploi (ans): </label>
                <input type="number" min="0" name="ant-duree" id="ant-duree">

                <span class="vide"><br></span><span class="vide"></span>

                
                <span class="vide"></span><i class="fa fa-plus-square" aria-hidden="true" id="addEmploi"> Ajouter cet emploi</i>

                <span class="vide"><br><br><br></span><span class="vide"></span>

                <b>Mes emplois antérieurs :</b><span class="vide"></span>
                <div id="mes-emplois">
                    <!--
                    <div class="emploi">
                        Entreprise :<span></span><br>
                        Poste :<span></span><br>
                        Durée (ans) :<span></span><br>
                        <i class="fa fa-minus-square" aria-hidden="true" class="suppEmp">: Supprimer cet emploi</i><span class="vide"></span>
                    </div><br>
                    -->
                </div>

            </div>

            <span></span>
            
        </div>

        <input type="hidden" name="action" value="emploi">
        
        <br>
        
        <div class="row">
            
            <button type="submit">Soumet ta candidature</button>
        </div>
    </fieldset>

</form>

<?php include_once("inc/footer.php"); ?>