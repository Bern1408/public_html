<?php 

class Client
{
    
    private $_idClient;
    private $_prenom;
    private $_nom;
    private $_courriel;
    private $_mdp;
    
    private $_pays;
    private $_adresse;
    private $_ville;
    private $_province;
    private $_codePostal;
    private $_typeTel;
    private $_tel;

    private $_paysDelivrance;
    private $_noPermis;
    private $_dateNaissance;
    private $_dateExpiration;

    private $_infolettre;
    private $_modalite;

    private $_reservationArray = array();

    public function __construct($params = array()){
  
        foreach($params as $k => $v){

            $methodName = "set_" . $k;            
            if(method_exists($this, $methodName)) {
                $this->$methodName($v);
            }   
        }
    }

    public function __serialize(){
        return [
            "idClient" => $this->_idClient,
            "prenom" => $this->_prenom,
            "nom" => $this->_nom,
            "courriel" => $this->_courriel,
            "mdp" => $this->_mdp,
            "pays" => $this->_pays,
            "adresse" => $this->_adresse,
            "ville" => $this->_ville,
            "province" => $this->_province,
            "codePostal" => $this->_codePostal,
            "typeTel" => $this->_typeTel,
            "tel" => $this->_tel,
            "paysDelivrance" => $this->_paysDelivrance,
            "noPermis" => $this->_noPermis,
            "dateNaissance" => $this->_dateNaissance,
            "dateExpiration" => $this->_dateExpiration,
            "infolettre" => $this->_infolettre,
            "modalite" => $this->_modalite,
            "reservationArray" => $this->_reservationArray
        ];
    }

    public function __unserialize($data){
        $this->_idClient = $data["idClient"];
        $this->_prenom = $data["prenom"];
        $this->_nom = $data["nom"];
        $this->_courriel = $data["courriel"];
        $this->_mdp = $data["mdp"];
        $this->_pays = $data["pays"];
        $this->_adresse = $data["adresse"];
        $this->_ville = $data["ville"];
        $this->_province = $data["province"];
        $this->_codePostal = $data["codePostal"];
        $this->_typeTel = $data["typeTel"];
        $this->_tel = $data["tel"];
        $this->_paysDelivrance = $data["paysDelivrance"];
        $this->_noPermis = $data["noPermis"];
        $this->_dateNaissance = $data["dateNaissance"];
        $this->_dateExpiration = $data["dateExpiration"];
        $this->_infolettre = $data["infolettre"];
        $this->_modalite = $data["modalite"];
        $this->_reservationArray = $data["reservationArray"]; 
    }

    public function addReservation($reservation) {
        array_push($this->_reservationArray, $reservation);
    }

    
    /**
     * Get the value of _prenom
     */ 
    public function get_prenom()
    {
        return $this->_prenom;
    }

    /**
     * Set the value of _prenom
     *
     * @return  self
     */ 
    public function set_prenom($_prenom)
    {
        $this->_prenom = $_prenom;

        return $this;
    }

    /**
     * Get the value of _nom
     */ 
    public function get_nom()
    {
        return $this->_nom;
    }

    /**
     * Set the value of _nom
     *
     * @return  self
     */ 
    public function set_nom($_nom)
    {
        $this->_nom = $_nom;

        return $this;
    }

    /**
     * Get the value of _courriel
     */ 
    public function get_courriel()
    {
        return $this->_courriel;
    }

    /**
     * Set the value of _courriel
     *
     * @return  self
     */ 
    public function set_courriel($_courriel)
    {
        $this->_courriel = $_courriel;

        return $this;
    }

    /**
     * Get the value of mdp
     */ 
    public function get_mdp()
    {
        return $this->_mdp;
    }

    /**
     * Set the value of mdp
     *
     * @return  self
     */ 
    public function set_mdp($mdp)
    {
        $this->_mdp = $mdp;

        return $this;
    }

    /**
     * Get the value of _pays
     */ 
    public function get_pays()
    {
        return $this->_pays;
    }

    /**
     * Set the value of _pays
     *
     * @return  self
     */ 
    public function set_pays($_pays)
    {
        $this->_pays = $_pays;

        return $this;
    }

    /**
     * Get the value of _adresse
     */ 
    public function get_adresse()
    {
        return $this->_adresse;
    }

    /**
     * Set the value of _adresse
     *
     * @return  self
     */ 
    public function set_adresse($_adresse)
    {
        $this->_adresse = $_adresse;

        return $this;
    }

    /**
     * Get the value of _ville
     */ 
    public function get_ville()
    {
        return $this->_ville;
    }

    /**
     * Set the value of _ville
     *
     * @return  self
     */ 
    public function set_ville($_ville)
    {
        $this->_ville = $_ville;

        return $this;
    }

    /**
     * Get the value of _codePostal
     */ 
    public function get_codePostal()
    {
        return $this->_codePostal;
    }

    /**
     * Set the value of _codePostal
     *
     * @return  self
     */ 
    public function set_codePostal($_codePostal)
    {
        $this->_codePostal = $_codePostal;

        return $this;
    }

    /**
     * Get the value of _typeTel
     */ 
    public function get_typeTel()
    {
        return $this->_typeTel;
    }

    /**
     * Set the value of _typeTel
     *
     * @return  self
     */ 
    public function set_typeTel($_typeTel)
    {
        $this->_typeTel = $_typeTel;

        return $this;
    }

    /**
     * Get the value of _tel
     */ 
    public function get_tel()
    {
        return $this->_tel;
    }

    /**
     * Set the value of _tel
     *
     * @return  self
     */ 
    public function set_tel($_tel)
    {
        $this->_tel = $_tel;

        return $this;
    }

    /**
     * Get the value of _paysDelivrance
     */ 
    public function get_paysDelivrance()
    {
        return $this->_paysDelivrance;
    }

    /**
     * Set the value of _paysDelivrance
     *
     * @return  self
     */ 
    public function set_paysDelivrance($_paysDelivrance)
    {
        $this->_paysDelivrance = $_paysDelivrance;

        return $this;
    }

    /**
     * Get the value of _noPermis
     */ 
    public function get_noPermis()
    {
        return $this->_noPermis;
    }

    /**
     * Set the value of _noPermis
     *
     * @return  self
     */ 
    public function set_noPermis($_noPermis)
    {
        $this->_noPermis = $_noPermis;

        return $this;
    }

    /**
     * Get the value of _dateNaissance
     */ 
    public function get_dateNaissance()
    {
        return $this->_dateNaissance;
    }

    /**
     * Set the value of _dateNaissance
     *
     * @return  self
     */ 
    public function set_dateNaissance($_dateNaissance)
    {
        $this->_dateNaissance = $_dateNaissance;

        return $this;
    }

    /**
     * Get the value of _dateExpiration
     */ 
    public function get_dateExpiration()
    {
        return $this->_dateExpiration;
    }

    /**
     * Set the value of _dateExpiration
     *
     * @return  self
     */ 
    public function set_dateExpiration($_dateExpiration)
    {
        $this->_dateExpiration = $_dateExpiration;

        return $this;
    }

    /**
     * Get the value of _infolettre
     */ 
    public function get_infolettre()
    {
        return $this->_infolettre;
    }

    /**
     * Set the value of _infolettre
     *
     * @return  self
     */ 
    public function set_infolettre($_infolettre)
    {
        $this->_infolettre = $_infolettre;

        return $this;
    }

    /**
     * Get the value of _modalite
     */ 
    public function get_modalite()
    {
        return $this->_modalite;
    }

    /**
     * Set the value of _modalite
     *
     * @return  self
     */ 
    public function set_modalite($_modalite)
    {
        $this->_modalite = $_modalite;

        return $this;
    }

    /**
     * Get the value of _province
     */ 
    public function get_province()
    {
        return $this->_province;
    }

    /**
     * Set the value of _province
     *
     * @return  self
     */ 
    public function set_province($_province)
    {
        $this->_province = $_province;

        return $this;
    }

    /**
     * Get the value of _reservation
     */ 
    public function get_reservationArray()
    {
        return $this->_reservationArray;
    }

    /**
     * Set the value of _reservation
     *
     * @return  self
     */ 
    public function set_reservationArray($_reservation)
    {
        array_push($this->_reservationArray, $_reservation);

        return $this;
    }

    /**
     * Get the value of _idClient
     */ 
    public function get_idClient()
    {
        return $this->_idClient;
    }

    /**
     * Set the value of _idClient
     *
     * @return  self
     */ 
    public function set_idClient($_idClient)
    {
        $this->_idClient = $_idClient;

        return $this;
    }
}



?>