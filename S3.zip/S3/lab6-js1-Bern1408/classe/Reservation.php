<?php 

class reservation
{
    private $_idReservation;
    private $_dateDebut;
    private $_dateFin;
    private $_ageLocataire;
    private $_voiture;

    public function __construct($params = array()){
        foreach($params as $k => $v){

            $methodName = "set_" . $k;            
            if(method_exists($this, $methodName)) {
                $this->$methodName($v);
            }   
        }
    }
    
    

    /**
     * Get the value of _dateDebut
     */ 
    public function get_dateDebut()
    {
        return $this->_dateDebut;
    }

    /**
     * Set the value of _dateDebut
     *
     * @return  self
     */ 
    public function set_dateDebut($_dateDebut)
    {
        $_dateDebut = new DateTime($_dateDebut);

        /*if($_dateDebut <= new DateTime()) {
            throw new Exception ("Date début passée");
        
        } elseif(isset($this->_dateFin)) {
            $limiteReservation = clone $_dateDebut;
            $limiteReservation->modify("+14 days");

            if( $_dateDebut > $this->_dateFin){
                throw new Exception ("Date de fin avant date de début");
            } else if($this->_dateFin > $limiteReservation) {
                throw new Exception ("Durée de location trop longue");
            }
        }*/

        $this->_dateDebut = $_dateDebut;
        return $this;
        
    }

    /**
     * Get the value of _dateFin
     */ 
    public function get_dateFin()
    {
        return $this->_dateFin;
    }

    /**
     * Set the value of _dateFin
     *
     * @return  self
     */ 
    public function set_dateFin($_dateFin)
    {

        $_dateFin = new DateTime($_dateFin);

        /*if(isset($this->_dateDebut)){
            $limiteReservation = clone $this->_dateDebut;
            $limiteReservation->modify("+14 days");

            if ($_dateFin < $this->_dateDebut){
                throw new Exception ("Date de fin avant date de début");

            } elseif($_dateFin > $limiteReservation){
                throw new Exception ("Durée de location trop longue");
            }
        } */

        $this->_dateFin = $_dateFin;
        return $this;
        
    }

    /**
     * Get the value of _ageLocataire
     */ 
    public function get_ageLocataire()
    {
        return $this->_ageLocataire;
    }

    /**
     * Set the value of _ageLocataire
     *
     * @return  self
     */ 
    public function set_ageLocataire($_ageLocataire)
    {
        if($_ageLocataire >= 25){
            $this->_ageLocataire = $_ageLocataire;
            return $this;
        } else {
            throw new Exception ("Trop jeune");
        }
    }

    /**
     * Get the value of _idVoiture
     */ 
    public function get_voiture()
    {
        return $this->_voiture;
    }

    /**
     * Set the value of _idVoiture
     *
     * @return  self
     */ 
    public function set_voiture($_voiture)
    {
        $this->_voiture = $_voiture;

        return $this;
    }


    /**
     * Get the value of _idReservation
     */ 
    public function get_idReservation()
    {
        return $this->_idReservation;
    }

    /**
     * Set the value of _idReservation
     *
     * @return  self
     */ 
    public function set_idReservation($_idReservation)
    {
        $this->_idReservation = $_idReservation;

        return $this;
    }
}



?>