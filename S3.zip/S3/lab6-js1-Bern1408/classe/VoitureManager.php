<?php
  require_once './classe/Voiture.php';

  class VoitureManager {
    private $_bd;

    public function __construct() { $this->_bd = PDOFactory::getMySQLConnection(); }

    public function getVoitures($filterArray = array()) {

      $voitureObjArray = $queryArray = array();
      $filterRequest = '';

      if (isset($filterArray['marque']) && $filterArray['marque'] !== 'all') {
        $filterRequest = "m.idMarque = :idMarque";
        $queryArray[':idMarque'] = $filterArray['marque'];
      }

      if (isset($filterArray['categorie']) && $filterArray['categorie'] !== 'all') {
        if (!empty($filterRequest))
          $filterRequest .= ' AND ';
        
        $filterRequest .= "c.idCategorie = :idCategorie";
        $queryArray[':idCategorie'] = $filterArray['categorie'];
      }

      if (isset($filterArray['mots_cles']) && !empty($filterArray['mots_cles']) ) {
        if (!empty($filterRequest)) {
          $filterRequest .= ' AND ';
        }

        $filterRequest .= ("description LIKE CONCAT('%', :description, '%')");
        $queryArray[':description'] = $filterArray['mots_cles'];
      }

      if (!empty($filterRequest)){
        $filterRequest =  ' WHERE ' . $filterRequest;
      }
        
      $query = $this->_bd->prepare("SELECT idVoiture, marque, modele, categorie, nbPassager, image, description  FROM tblVoiture AS v INNER JOIN tblMarque AS m ON v.idMarque = m.idMarque INNER JOIN tblCategorie AS c ON v.idCategorie = c.idCategorie" . $filterRequest);
      $query->execute($queryArray);
      $dbResult = $query->fetchAll();

      foreach ($dbResult as $row){
        array_push($voitureObjArray, new Voiture($row));
      }

      return $voitureObjArray;
    }

    public function getVoitureById(int $idVoiture) {
        
      $query = $this->_bd->prepare("SELECT idVoiture, marque, modele, categorie, nbPassager, image, description  FROM tblVoiture AS v INNER JOIN tblMarque AS m ON v.idMarque = m.idMarque INNER JOIN tblCategorie AS c ON v.idCategorie = c.idCategorie WHERE idVoiture = :idVoiture");
      $query->execute(array("idVoiture" => $idVoiture));
      $dbResult = $query->fetch();

      if($dbResult) {
        return new Voiture($dbResult);
      } else {
        return null;
      }      
    }

    public function getMarque() {

      $marqueArray = $this->_bd->query("SELECT idMarque AS id, marque FROM tblMarque ORDER BY marque")->fetchAll();

      return $marqueArray;
    }

    public function getCategorie() {

      $categorieArray = $this->_bd->query("SELECT idCategorie AS id, categorie FROM tblCategorie ORDER BY categorie")->fetchAll();

      return $categorieArray;
    }
        
  };
?>