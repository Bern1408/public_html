<?php

  class ReservationManager {
    private $_bd;

    public function __construct() { $this->_bd = PDOFactory::getMySQLConnection(); }

    public function addReservation($idClient, $reservationObj) {
      $query = $this->_bd->prepare("INSERT INTO tblReservation (idClient, idVoiture, ageLocataire, dateDebut, dateFin) VALUES (:idClient, :idVoiture, :ageLocataire, :dateDebut, :dateFin)");
      
      $ReservationArray = array(
                            ':idClient' => $idClient,
                            ':idVoiture' => $reservationObj->get_voiture()->get_idVoiture(),
                            ':ageLocataire' => $reservationObj->get_ageLocataire(),
                            ':dateDebut' => $reservationObj->get_dateDebut()->format('Y-m-d'),
                            ':dateFin' => $reservationObj->get_dateFin()->format('Y-m-d')
                          );

      $query->execute($ReservationArray);

      return $this->_bd->lastInsertId();
    }

    public function delReservation($idClient, $idReservation) {
      $query = $this->_bd->prepare("DELETE FROM tblReservation WHERE idReservation = :idReservation AND idClient = :idClient");
      $deleteArray = array(
                            ':idReservation' => $idReservation,
                            ':idClient' => $idClient
                          );
      $query->execute($deleteArray);
      return $query->rowCount(); // retourne le nb de ligne affecté
    }

    public function getReservationClient($idClient, $boolReservationEncours) {

      $filtreActuelPassee = ($boolReservationEncours ? " AND datefin >= NOW()" : " AND datefin < NOW()" );

      $query = $this->_bd->prepare("SELECT * FROM tblReservation WHERE idClient = :idClient " . $filtreActuelPassee);
      $query->execute(array(':idClient' => $idClient));

      $arrReservations = array();

      while($bddResult = $query->fetch()){
        //Get l'objet Voiture selon son id pour l'ajouter dans la rservation. 
        $cm = new VoitureManager($this->_bd);
        $bddResult['Voiture'] = $cm->getVoitureById($bddResult['idVoiture']);

        array_push($arrReservations, new Reservation($bddResult));
      }

      return $arrReservations;
    }

  };
?>