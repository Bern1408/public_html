<?php

  class ClientManager {
    private $_bd;

    public function __construct() { $this->_bd = PDOFactory::getMySQLConnection(); }

    public function clientExiste(string $courriel, string $motPasse) {
      $query = $this->_bd->prepare("SELECT idClient , nom, prenom FROM tblClient WHERE courriel = :courriel AND mdp = :motPasse");

      $loginArray = array(
                          ':courriel' => $courriel,
                          ':motPasse' => $motPasse
                         );

      $query->execute($loginArray);

      if($bddResult = $query->fetch()){
        return new Client($bddResult);
      } else {
        return null;
      }
    }

    public function addClient($clientObj) {
      
      $query = $this->_bd->prepare("INSERT INTO tblClient (prenom, nom, courriel, mdp, adresse, ville, province, codePostal, idPays, idTypeTel, tel, idPaysDelivrance, noPermis, dateNaissance, dateExp, infolettre, modalite, dateCreation) VALUES 
      (:prenom, :nom, :courriel, :motPasse, :adresse, :ville, :province, :codePostal, :pays, 
      :typeTel, :telephone, :paysDelivrance, :permis, :dateNaissance, :dateExpiration, :promotions, :modalites, CURRENT_DATE())");

      $query->bindValue(':prenom', $clientObj->get_prenom());
      $query->bindValue(':nom', $clientObj->get_nom());
      $query->bindValue(':courriel', $clientObj->get_courriel());
      $query->bindValue(':motPasse', $clientObj->get_mdp());
      $query->bindValue(':adresse', $clientObj->get_adresse());
      $query->bindValue(':ville', $clientObj->get_ville());
      $query->bindValue(':province', $clientObj->get_province());
      $query->bindValue(':codePostal', $clientObj->get_codePostal());
      $query->bindValue(':pays', $clientObj->get_pays());
      $query->bindValue(':typeTel', $clientObj->get_typeTel());
      $query->bindValue(':telephone', $clientObj->get_tel());
      $query->bindValue(':paysDelivrance', $clientObj->get_paysDelivrance());
      $query->bindValue(':permis', $clientObj->get_noPermis());
      $query->bindValue(':dateNaissance', $clientObj->get_dateNaissance());
      $query->bindValue(':dateExpiration', $clientObj->get_dateExpiration());
      $query->bindValue(':promotions', ($clientObj->get_infolettre() == 'Oui' ? true : false),PDO::PARAM_BOOL);
      $query->bindValue(':modalites', ($clientObj->get_modalite() == 'Oui' ? true : false),PDO::PARAM_BOOL);                              
      
      $query->execute();

      return $this->_bd->lastInsertId();
    }

    public function get_client_info($idClient){
      $query = $this->_bd->prepare("SELECT idClient, prenom, nom, courriel, tel, noPermis, dateNaissance, dateExp AS dateExpiration, infolettre, modalite FROM tblClient WHERE idClient = :idClient");

      $query->execute(array(':idClient' => $idClient));

      if($bddResult = $query->fetch()){
        return new Client($bddResult);
      } else {
        return null;
      }


    }

    public function getPays() {
      $paysArray = $this->_bd->query("SELECT * FROM tblPays")->fetchAll(PDO::FETCH_ASSOC);
      return $paysArray;
    }

    public function getPaysByID($id) {
      $stmt = $this->_bd->prepare("SELECT * FROM tblPays WHERE idPays = :pays");
      $stmt->execute([':pays'=>$id]);
      $paysArray = $stmt->fetch(PDO::FETCH_ASSOC);
      return $paysArray['pays'];
    }

    public function getTypeTel() {
      $TypeTelArray = $this->_bd->query("SELECT * FROM tblTypeTel")->fetchAll(PDO::FETCH_ASSOC);
      return $TypeTelArray;
    }

    public function getTypeTelByID($id) {
      $stmt = $this->_bd->prepare("SELECT * FROM tblTypeTel WHERE idTypeTel = :TypeTel");
      $stmt->execute([':TypeTel'=>$id]);
      $TypeTelArray = $stmt->fetch(PDO::FETCH_ASSOC);
      return $TypeTelArray['typeTel'];
    }
        
  };

?>