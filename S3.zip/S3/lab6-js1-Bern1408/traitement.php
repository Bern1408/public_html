<?php 
    include_once("inc/pretraitement.php");
    include_once("inc/header.php"); 
?>

<h1 class="center">Informations reçues !</h1>

<?php 
    if(isset($_REQUEST['action'])) {
        if($_REQUEST['action'] == "inscription") {
            $cm = new ClientManager();
            $client = new Client($_REQUEST);
            $cm->addClient($client);
?>
        <ul class="traitement">
            <li>Profil
                <ul>
                    <li><span>Prénom: </span><?= $client->get_prenom(); ?></li>
                    <li><span>Nom: </span><?= $client->get_nom(); ?></li>
                    <li><span>Courriel: </span><?= $client->get_courriel(); ?></li>
                    <li><span>Mot de passe: </span><?= $client->get_mdp(); ?></li>
                </ul>
            </li>
            <li>Coordonnées
                <ul>
                    <li><span>Pays: </span><?= $cm->getPaysByID($client->get_pays()); ?></li>
                    <li><span>Adresse: </span><?= $client->get_adresse(); ?></li>
                    <li><span>Ville: </span><?= $client->get_ville(); ?></li>
                    <li><span>Province: </span><?= $client->get_province(); ?></li>
                    <li><span>Code postal: </span><?= $client->get_codePostal(); ?></li>
                    <li><span>Type Téléphone: </span><?= $cm->getTypeTelByID($client->get_typeTel()); ?></li>
                    <li><span>Téléphone: </span><?= $client->get_tel(); ?></li>
                </ul>
            </li>
            <li>Information conducteur
                <ul>
                    <li><span>Pays de délivrance: </span><?= $cm->getPaysByID($client->get_paysDelivrance()); ?></li>
                    <li><span>Date de naissance: </span><?= $client->get_dateNaissance(); ?></li>
                    <li><span>Numéro de permis: </span><?= $client->get_noPermis(); ?></li>
                    <li><span>Date d'expiration: </span><?= $client->get_dateExpiration(); ?></li>
                </ul>
            </li>
            <li>Préférence
                <ul>
                    <li><span>Infolettre: </span><?= ($client->get_infolettre() == "Oui" ? $client->get_infolettre() : "Non" ); ?></li>
                    <li><span>Modalité: </span><?= ($client->get_modalite()  == "Oui" ? $client->get_modalite() : "Non" ); ?></li>
                </ul>
            </li>
        </ul>

    <?php } elseif ($_REQUEST['action'] == "connexion"){ ?>
        <?php 
            if(isset($_SESSION['client'])){
                $client = unserialize($_SESSION['client']); 
        ?>
                <h1 class="center">Bienvenue <?= $client->get_prenom() . " " . $client->get_nom(); ?> </h1>
        <?php } else { 
                echo "<h1 class='center'>Erreur d'authentification </h1>"; 
            } 
        ?>
            

    <?php } elseif ($_REQUEST['action'] == "logout"){ ?>
        <h1 class="center">Au revoir !</h1>

    <?php } elseif ($_REQUEST['action'] == "reservation") { 
        
        //Crée l'objet voiture selon l'id de la voiture reçu dans le formulaire.
        $vm = new VoitureManager();
        $voitureSelectionne = $_REQUEST["voiture"] = $vm->getVoitureById($_REQUEST['voiture']);
        
        $client = unserialize($_SESSION['client']);
        $cm = new ClientManager();

        try{
            $reservation = new Reservation($_REQUEST);
            $client = $cm->get_client_info($client->get_idClient());

            if($client->get_noPermis() == null || empty($client->get_noPermis())){
                throw new Exception ("Pas de no de permis");
            }
            
            if(new DateTime($client->get_dateExpiration()) < $reservation->get_dateFin()){
                throw new Exception ("Permis expiré ou sera expiré durant la location");
            }


        } catch (Exception $e){
            header("location:reservation.php?erreur=".$e->getMessage());
        }
        
        // Ajoute la réservation dans la BD
        
        $rm = new ReservationManager();
        $rm->addReservation($client->get_idClient(), $reservation);

        // Il n'est plus tant utile de maintenir un array de réservation dans l'objet client. 
        // Il suffira de demander à la BD de retourner les réservations d'un client.
        //$client->addReservation($reservation);  
        //$_SESSION['client'] = serialize($client);

    ?>
        
        <h2 class="center">Merci pour votre confiance <?= $client->get_nom(); ?> !</h2>
        <h3 class="center">Votre réservation</h3>

        <ul class="traitement">
            <li><span>Date de début: </span><?= $reservation->get_datedebut()->format('Y-m-d');  ?></li>
            <li><span>Date de fin: </span><?= $reservation->get_datefin()->format('Y-m-d'); ?></li>
            <li><span>Age du locataire: </span><?= $reservation->get_ageLocataire(); ?> </li>
            <li><span>Voiture sélectionnée: </span>
                <?php
                    echo $voitureSelectionne->get_marque() . " " . $voitureSelectionne->get_modele() . " - " . $voitureSelectionne->get_categorie();
                ?>
            </li>
        </ul>

        
    <?php } elseif ($_REQUEST['action'] == "delReservation" && isset($_REQUEST['idReservation'])){
        
        $client = unserialize($_SESSION['client']);
        $rm = new ReservationManager();
        
        if($rm->delReservation($client->get_idClient(), $_REQUEST['idReservation'])){
            echo "Réservation supprimée !";
        } else {
            echo "ERREUR - Réservation NON supprimée !";
        }


        
    }  
} 
?>

<?php include_once("inc/footer.php"); ?>