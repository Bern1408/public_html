
</main>

<footer class="grid">
    <p class="center">copyright Simon Guimond Dufour</p>
    <div>
        <button name="theme" id="standart">Mode standart</button>
        <button name="theme" id="sombre">Mode sombre</button>
    </div>
</footer>

</body>
</html>