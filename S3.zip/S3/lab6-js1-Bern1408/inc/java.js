function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  document.cookie = `${cname}=${encodeURIComponent(cvalue)};expires=${d.toUTCString()};path=/`;
}
function getCookie(cname) {
  const name = cname + "=";
  const cookies = document.cookie.split(';');
  let ca = decodedCookie.split(';');
  for(let c of cookies) {
    c = c.trim();
    if (c.indexOf(name) === 0) {
      return decodeURIComponent(c.substring(name.length, c.length));
    }
  }
  return null;
}


function changeTheme(evt) {
  if(evt.target.id == 'sombre') {
    document.body.classList.add('sombre');
      setCookie("oreo", "sombre" , 1);
  }
  else{
    document.body.classList.remove('sombre');
      setCookie("oreo", "standart", 1);
  }

}
document.getElementById('standart').addEventListener('click', changeTheme);
document.getElementById('sombre').addEventListener('click', changeTheme);

function areYouSure(evt) {
  let confirmation = confirm("Êtes-vous certain de vouloir annuler cette réservation ?");
  if(confirmation == false) {
    evt.preventDefault()
  }
}
document.getElementById('annuler').addEventListener('click', areYouSure);

function unhideDescription(evt) {
  //if(evt.target
}
document.getElementById('showDescription').addEventListener('click', unhideDescription);