<?php 

class VoitureManager{
    private $bd;

    public function __construct(){
        $this->bd = PDOFactory::getMySQLConnection();
    }

    public function getVoitures(){
        $listeVoitures = array();
        $requete = $this->bd->query('SELECT * FROM tblVoiture INNER JOIN tblMarque ON tblVoiture.idMarque=tblMarque.idMarque' );
        while ($voiture = $requete->fetch(PDO::FETCH_ASSOC)) {
            $listeVoitures[] = new voiture($voiture);
        }

        return $listeVoitures;
    }

    public function getVoiture($id){

        $requete = $this->bd->query("SELECT * FROM tblVoiture INNER JOIN tblMarque ON tblVoiture.idMarque=tblMarque.idMarque WHERE idVoiture='$id'");
        $voiture = new voiture($requete->fetch(PDO::FETCH_ASSOC));

        return $voiture;
    }

    public function getMarques(){
        $requete = $this->bd->query("SELECT * FROM tblMarque");
        $marques = array($requete->fetch(PDO::FETCH_ASSOC));

        return $marques;
    }
    public function getCategories(){
        $requete = $this->bd->query("SELECT * FROM tblCategorie");
        $categories = array($requete->fetch(PDO::FETCH_ASSOC));

        return $categories;
    }
}

    

?>