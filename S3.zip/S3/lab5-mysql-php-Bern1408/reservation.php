<?php include_once("inc/header.php"); ?>

<h1 class="center">Réservez votre voiture</h1>

<?php if(isset($_SESSION['client'])){ ?>

    <form class="reservation" action="traitement.php" method="post">

        <div class="row">
            <label for="dateDebut">Début de location</label>
            <input type="date" name="dateDebut" id="dateDebut">

            <label for="dateFin">Fin de location</label>
            <input type="date" name="dateFin" id="dateFin">
        </div>

        <div class="row">
            <label for="ageLocataire">Age du locataire</label>
            <input type="number" name="ageLocataire" id="ageLocataire">
        </div>

        <hr>

        <label for="">Sélectionnez votre voiture</label>
        <div class="row wrap">
            

        <?php foreach($voitures as $voiture){ ?>
            <div class="row select-car col-6">
                <input type="radio" name="voiture" id="vid0" value="<?= $voiture->get_idVoiture(); ?>">
                <img src="img/<?= $voiture->get_image(); ?>" alt="<?= $voiture->get_marque() . " " . $voiture->get_modele(); ?>">
                <h3><?= $voiture->get_marque() . " " . $voiture->get_modele(); ?></h3>
            </div>
        <?php } ?>
                   
        </div>

        <input type="hidden" name="action" value="reservation">

        <div class="row row-right">
            <button type="submit">Réserver la voiture</button>
        </div>

    </form>

<?php } else { ?>
    <h2 class="center">Vous n'êtes pas connecté. <br> Veuillez ouvrir une session pour réserver une voiture.</h2>

<?php } ?>

<?php include_once("inc/footer.php"); ?>