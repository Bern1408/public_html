<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
} 

include_once("inc/autoloader.php");
include_once("inc/pretraitement.php");
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Réservation de voiture</title>
</head>

<body>

    <main>

        <nav class="upper-menu">
            <ul>
                <li><a href="register.php">Inscription</a></li>

                <?php if(isset($_SESSION['client'])){ ?>
                    <li><a href="traitement.php?action=logout">Se déconnecter</a></li>
                <?php } else { ?>
                    <li><a href="login.php">Se connecter</a></li>                    
                <?php } ?>
            </ul>
        </nav>

        <nav class="main-menu">
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="voitures.php">Les voitures</a></li>
                <li><a href="reservation.php">Réserver une voiture</a></li>
                <li><a href="mes-reservations.php">Mes réservations</a></li>
            </ul>
        </nav>


        <img src="img/logo.jpg" alt="logo">