<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once("inc/autoloader.php");

if (isset($_REQUEST['action']) && $_REQUEST['action'] == "connexion"){ 
    $client = new Client(array("nom" => $_REQUEST['username']));
    $_SESSION['client'] = serialize($client);
    
} else if (isset($_REQUEST['action']) && $_REQUEST['action'] == "logout"){
    $_SESSION = array();
    session_destroy(); 
} ?>