<?php 

class voiture {

    private $_idVoiture;
    private $_marque;
    private $_modele;
    private $_categorie;
    private $_nbpassager;
    private $_image;
    private $_description;

    public function __construct($params = array()){
        
        foreach($params as $k => $v){

            $methodName = "set_" . $k;            
            if(method_exists($this, $methodName)) {
                $this->$methodName($v);
            }   
        }
    }


    /**
     * Get the value of _id
     */ 
    public function get_idVoiture()
    {
        return $this->_idVoiture;
    }

    /**
     * Set the value of _id
     *
     * @return  self
     */ 
    public function set_idVoiture($_idVoiture)
    {
        $this->_idVoiture = $_idVoiture;

        return $this;
    }

    /**
     * Get the value of _marque
     */ 
    public function get_marque()
    {
        return $this->_marque;
    }

    /**
     * Set the value of _marque
     *
     * @return  self
     */ 
    public function set_marque($_marque)
    {
        $this->_marque = $_marque;

        return $this;
    }

    /**
     * Get the value of _modele
     */ 
    public function get_modele()
    {
        return $this->_modele;
    }

    /**
     * Set the value of _modele
     *
     * @return  self
     */ 
    public function set_modele($_modele)
    {
        $this->_modele = $_modele;

        return $this;
    }

    /**
     * Get the value of _categorie
     */ 
    public function get_categorie()
    {
        return $this->_categorie;
    }

    /**
     * Set the value of _categorie
     *
     * @return  self
     */ 
    public function set_categorie($_categorie)
    {
        $this->_categorie = $_categorie;

        return $this;
    }

    /**
     * Get the value of _passager
     */ 
    public function get_nbpassager()
    {
        return $this->_nbpassager;
    }

    /**
     * Set the value of _passager
     *
     * @return  self
     */ 
    public function set_nbpassager($_nbpassager)
    {
        $this->_nbpassager = $_nbpassager;

        return $this;
    }

    /**
     * Get the value of _image
     */ 
    public function get_image()
    {
        return $this->_image;
    }

    /**
     * Set the value of _image
     *
     * @return  self
     */ 
    public function set_image($_image)
    {
        $this->_image = $_image;

        return $this;
    }

    /**
     * Get the value of _description
     */ 
    public function get_description()
    {
        return $this->_description;
    }

    /**
     * Set the value of _description
     *
     * @return  self
     */ 
    public function set_description($_description)
    {
        $this->_description = $_description;

        return $this;
    }
}


?>