<?php

  class ClientManager {
    private $_bd;


    const ADRESSE_EXISTE = "SELECT idAdresse FROM tblAdresse WHERE adresse = :adresse AND codePostal = :codePostal";
    
    const INSERT_ADRESSE = "INSERT INTO tblAdresse (adresse, ville, province, codePostal, idPays) VALUES (:adresse, :ville, :province, :codePostal, (SELECT idPays FROM tblPays WHERE pays LIKE CONCAT('%', :pays, '%')))";

    const INSERT_CLIENT = "INSERT INTO tblClient (prenom, nom, courriel, mdp, adresse, ville, province, codePostal, idPays, idTypeTel, tel, idPaysDelivrance, noPermis, dateNaissance, dateExp, infolettre, modalite, dateCreation) VALUES (:prenom, :nom, :courriel, :motPasse, :adresse, :ville, :province, :codePostal, :idPays, :typeTel, :telephone, :paysDelivrance, :permis, :dateNaissance, :dateExpiration, :promotions, :modalites, CURRENT_DATE())";


    public function __construct() { $this->_bd = PDOFactory::getMySQLConnection(); }

    private function addressExiste(string $codePostal, string $adresse) {
      $query = $this->_bd->prepare(self::ADRESSE_EXISTE);
      $query->execute(array(':codePostal' => $codePostal, 'adresse' => $adresse));

      return $query->fetchColumn();
    }

    private function addAdresse($clientObj) {
      $idAdresse = $this->addressExiste($clientObj->get_codePostal(), $clientObj->get_adresse());

      if ($idAdresse)
        return $idAdresse;

      else {        
        $query = $this->_bd->prepare(self::INSERT_ADRESSE);
        
        $adresseArray = array(
                              ':adresse' => $clientObj->get_adresse(),
                              ':ville' => $clientObj->get_ville(),
                              ':province' => $clientObj->get_province(),
                              ':codePostal' => $clientObj->get_codePostal(),
                              ':pays' => $clientObj->get_pays()
                            );
        
        assert($query->execute($adresseArray), 'L\'adresse n\'a pas pu être insérée dans la table "tblAdresse".'); 

        return $this->_bd->lastInsertId();
      }
    }

    public function clientExiste(string $courriel, string $motPasse) {
      $query = $this->_bd->prepare("SELECT idClient , nom, prenom FROM tblClient WHERE courriel = :courriel AND mdp = :motPasse");

      $loginArray = array(
                          ':courriel' => $courriel,
                          ':motPasse' => $motPasse
                         );

      $query->execute($loginArray);

      if($bddResult = $query->fetch()){
        return new Client($bddResult);
      } else {
        return null;
      }
    }

    public function addClient($clientObj) {
      
      $query = $this->_bd->prepare("INSERT INTO tblClient (prenom, nom, courriel, mdp, adresse, ville, province, codePostal, idPays, idTypeTel, tel, idPaysDelivrance, noPermis, dateNaissance, dateExp, infolettre, modalite, dateCreation) VALUES 
      (:prenom, :nom, :courriel, :motPasse, :adresse, :ville, :province, :codePostal, :pays, 
      :typeTel, :telephone, :paysDelivrance, :permis, :dateNaissance, :dateExpiration, :promotions, :modalites, CURRENT_DATE())");

      $query->bindValue(':prenom', $clientObj->get_prenom());
      $query->bindValue(':nom', $clientObj->get_nom());
      $query->bindValue(':courriel', $clientObj->get_courriel());
      $query->bindValue(':motPasse', $clientObj->get_mdp());
      $query->bindValue(':adresse', $clientObj->get_adresse());
      $query->bindValue(':ville', $clientObj->get_ville());
      $query->bindValue(':province', $clientObj->get_province());
      $query->bindValue(':codePostal', $clientObj->get_codePostal());
      $query->bindValue(':pays', $clientObj->get_pays());
      $query->bindValue(':typeTel', $clientObj->get_typeTel());
      $query->bindValue(':telephone', $clientObj->get_tel());
      $query->bindValue(':paysDelivrance', $clientObj->get_paysDelivrance());
      $query->bindValue(':permis', $clientObj->get_noPermis());
      $query->bindValue(':dateNaissance', $clientObj->get_dateNaissance());
      $query->bindValue(':dateExpiration', $clientObj->get_dateExpiration());
      $query->bindValue(':promotions', ($clientObj->get_infolettre() == 'Oui' ? true : false),PDO::PARAM_BOOL);
      $query->bindValue(':modalites', ($clientObj->get_modalite() == 'Oui' ? true : false),PDO::PARAM_BOOL);                              
      
      $query->execute();

      return $this->_bd->lastInsertId();
    }

    public function getPays() {
      $paysArray = $this->_bd->query("SELECT * FROM tblPays")->fetchAll(PDO::FETCH_ASSOC);
      return $paysArray;
    }

    public function getPaysByID($id) {
      $stmt = $this->_bd->prepare("SELECT * FROM tblPays WHERE idPays = :pays");
      $stmt->execute([':pays'=>$id]);
      $paysArray = $stmt->fetch(PDO::FETCH_ASSOC);
      return $paysArray['pays'];
    }

    public function getTypeTel() {
      $TypeTelArray = $this->_bd->query("SELECT * FROM tblTypeTel")->fetchAll(PDO::FETCH_ASSOC);
      return $TypeTelArray;
    }

    public function getTypeTelByID($id) {
      $stmt = $this->_bd->prepare("SELECT * FROM tblTypeTel WHERE idTypeTel = :TypeTel");
      $stmt->execute([':TypeTel'=>$id]);
      $TypeTelArray = $stmt->fetch(PDO::FETCH_ASSOC);
      return $TypeTelArray['typeTel'];
    }
        
  };

?>