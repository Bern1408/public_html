<?php 

class reservation
{
    private $_idReservation;
    private $_dateDebut;
    private $_dateFin;
    private $_ageLocataire;
    private $_voiture;

    public function __construct($params = array()){
        foreach($params as $k => $v){

            $methodName = "set_" . $k;            
            if(method_exists($this, $methodName)) {
                $this->$methodName($v);
            }   
        }
    }
    
    

    /**
     * Get the value of _dateDebut
     */ 
    public function get_dateDebut()
    {
        return $this->_dateDebut;
    }

    /**
     * Set the value of _dateDebut
     *
     * @return  self
     */ 
    public function set_dateDebut($_dateDebut)
    {
        $this->_dateDebut = $_dateDebut;

        return $this;
    }

    /**
     * Get the value of _dateFin
     */ 
    public function get_dateFin()
    {
        return $this->_dateFin;
    }

    /**
     * Set the value of _dateFin
     *
     * @return  self
     */ 
    public function set_dateFin($_dateFin)
    {
        $this->_dateFin = $_dateFin;

        return $this;
    }

    /**
     * Get the value of _ageLocataire
     */ 
    public function get_ageLocataire()
    {
        return $this->_ageLocataire;
    }

    /**
     * Set the value of _ageLocataire
     *
     * @return  self
     */ 
    public function set_ageLocataire($_ageLocataire)
    {
        $this->_ageLocataire = $_ageLocataire;

        return $this;
    }

    /**
     * Get the value of _idVoiture
     */ 
    public function get_voiture()
    {
        return $this->_voiture;
    }

    /**
     * Set the value of _idVoiture
     *
     * @return  self
     */ 
    public function set_voiture($_voiture)
    {
        $this->_voiture = $_voiture;

        return $this;
    }


    /**
     * Get the value of _idReservation
     */ 
    public function get_idReservation()
    {
        return $this->_idReservation;
    }

    /**
     * Set the value of _idReservation
     *
     * @return  self
     */ 
    public function set_idReservation($_idReservation)
    {
        $this->_idReservation = $_idReservation;

        return $this;
    }
}



?>