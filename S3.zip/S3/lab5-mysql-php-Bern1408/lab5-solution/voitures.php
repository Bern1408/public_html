<?php 
include_once("inc/header.php"); 
$vm = new VoitureManager();
?>

<h1 class="center">Voitures disponible !</h1>

<!-- Liste les voitures -->
<?php if(!isset($_GET['id'])) { ?>

<?php 
    

    $marqueArray = $vm->getMarque();
    $categorieArray = $vm->getCategorie(); ?>

    <form action="./voitures.php" method="post" class="center">
        <label for="marque">Marque</label>
        <select name="marque" id="marque">
            <option value="all" selected>Toutes</option>

                <?php 
                    foreach ($marqueArray as $marque) {
                        echo '<option value="' . $marque['id'] . '">' . $marque['marque'] . '</option>';
                    }
                ?>
        </select>
            
        <label for="categorie">Categorie</label>
        <select name="categorie" id="categorie">
            <option value="all" selected>Toutes</option>';

            <?php
                foreach ($categorieArray as $categorie){
                    echo '<option value="' . $categorie['id'] . '">' . $categorie['categorie'] . '</option>';
                }
            ?>

        </select>

        <label for="mots_cles">Mots-clés</label>
        <input type="search" name="mots_cles" id="mots_cles" />

        <input type="hidden" name="action" value="filtre" />
        <button type="submit">Filtrer</button>
    </form>
    <hr />

<h2 class="center">Sélectionnez une voiture pour en savoir plus</h2>

<ul class="center lst-car">
    <?php 
    
    if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'filtre'){
        $voitures = $vm->getVoitures($_REQUEST);
    } else {
        $voitures = $vm->getVoitures();
    }
        
    foreach ($voitures as $voiture) { 
        echo '<li><a href="voitures.php?id=' . $voiture->get_idVoiture() . '">' . $voiture->get_marque() . ' ' . $voiture->get_modele() .'</a></li>'; 
    } ?>

</ul>

<!-- Affiche le détail de une voiture -->
<?php } else { ?>

<section class="voiture">

<?php 
    $voiture = $vm->getVoitureById($_REQUEST['id']);

    // Si on a trouvé
    if(isset($voiture)){


?>

    <h2><?php echo $voiture->get_marque() . " " . $voiture->get_modele() . " - " . $voiture->get_categorie() ?>
    </h2>

    <div class="row">
        <img src="img/<?php echo  $voiture->get_image() ?>"
            alt="<?php echo $voiture->get_marque() . " " . $voiture->get_modele(); ?>"> <br>

        <p>
            Passager: <?php echo  $voiture->get_nbpassager() ?> <br> <br>
            Description: <?php echo  $voiture->get_description() ?>
        </p>
    </div>

    <?php
    //Si l'ID de la voiture n'est pas trouvée.
    } else {
        echo "<h2>Cette voiture n'existe pas</h2>";
    }
    
    ?>

    <a class="right" href="voitures.php">Retour à la liste des voitures</a>

</section>
<?php } ?>

<?php include_once("inc/footer.php"); ?>