<?php
session_start();

include_once("inc/autoloader.php");

if (isset($_REQUEST['action']) && $_REQUEST['action'] == "connexion"){
    $cm = new ClientManager(); 
    $client = $cm->clientExiste($_REQUEST['username'], $_REQUEST['mdp']);

    //Si login ok
    if(is_a($client,'Client')){
        $_SESSION['client'] = serialize($client);
    }
    
} else if (isset($_REQUEST['action']) && $_REQUEST['action'] == "logout"){
    $_SESSION = array();
    session_destroy(); 
} ?>