<?php include_once("inc/header.php"); ?>
<?php 
    $cm = new ClientManager(); 
    $pays = $cm->getPays();
    $typeTel = $cm->getTypeTel();
?>

<h1 class="center">Création de votre compte</h1>

<form action="traitement.php" method="post" class="register">
    <fieldset class="profil">
        <legend>Mon profil</legend>
        <div class="grid">
            <label for="prenom">Prénom: </label>
            <input type="text" name="prenom" id="prenom" value="">

            <label for="nom">Nom: </label>
            <input type="text" name="nom" id="nom" value="">

            <label for="courriel">Courriel: </label>
            <input type="email" name="courriel" id="courriel" value="">

            <label for="pass">Mot de passe: </label>
            <input type="password" name="mdp" id="pass" value="">
        </div>


    </fieldset>

    <fieldset class="coord">
        <legend>Coordonnées</legend>

        <div class="grid">
            <label for="pays">Pays: </label>
            <select name="pays" id="pays">
                <?php foreach($pays as $p) { ?>
                    <option value="<?= $p['idPays']; ?>"><?= $p['pays']; ?></option>
                <?php } ?>
            </select>
            <span> </span><span> </span>
        
            <label for="adresse">Adresse: </label>
            <input type="text" name="adresse" id="adresse" value="">
        
            <label for="ville">Ville: </label>
            <input type="text" name="ville" id="ville" value="">

            <label for="province">Province: </label>
            <input type="text" name="province" id="province" value="">
        
            <label for="cp">Code postal: </label>
            <input type="text" name="codePostal" id="cp" value="">
        
            <label for="typetel">Type: </label>
            <select name="typeTel" id="typetel">
                <?php foreach($typeTel as $t) { ?>
                    <option value="<?= $t['idTypeTel']; ?>"><?= $t['typeTel']; ?></option>
                <?php } ?>
            </select>

            <label for="tel">Téléphone: </label>
            <input type="tel" name="tel" id="tel" value="">
        </div>
    </fieldset>

    <fieldset class="info-cond">
        <legend>Informations sur le conducteur</legend>

        <div class="grid">
            <label for="pays-delivrance">Pays de délivrance: </label>
            <select name="paysDelivrance" id="pays-delivrance">
                <?php foreach($pays as $p) { ?>
                    <option value="<?= $p['idPays']; ?>"><?= $p['pays']; ?></option>
                <?php } ?>
            </select>

            <label for="ddn">Date de naissance: </label>
            <input type="date" name="dateNaissance" id="ddn" value="">
        
            <label for="numero-permis">Numéro de permis: </label>
            <input type="text" name="noPermis" id="numero-permis" value="">

            <label for="dde">Date d'expiration: </label>
            <input type="date" name="dateExpiration" id="dde" value="">
        </div>
    </fieldset>

    <fieldset class="pref">
        <legend>Préférences</legend>

        <div class="grid">
            <input type="checkbox" name="infolettre" id="infolettre" value="Oui">
            <label for="infolettre">Je souhaite recevoir les promotion par courriel: </label>
        
            <input type="checkbox" name="modalite" id="modalite" value="Oui">
            <label for="modalite">J'accepte les modalités: </label>
        
            <span></span>
            <input type="hidden" name="action" value="inscription">
            <button type="submit">Créer le compte</button>
        </div>
    </fieldset>

</form>

<?php include_once("inc/footer.php"); ?>