<?php include_once("inc/header.php"); ?>

<h1 class="center">Bienvenue sur ce site de location de voiture</h1>
<h2 class="center">Nos voitures vous mènerons là où vous le souhaitez avec style !</h2>

<?php include_once("inc/footer.php"); ?>