<?php include_once("inc/header.php"); ?>

<h1 class="center">Informations reçues !</h1>

<?php 
    if(isset($_REQUEST['action'])) {
        if($_REQUEST['action'] == "inscription") {
            
            //En s'assurant que les attributs name des inputs du formulaire
            //correspondent aux attributs de la classe Client
            //on peut instancier un objet Client en lui passant $_REQUEST
            //comme argument du constructeur.
            $client = new Client($_REQUEST);
?>
        <ul class="traitement">
            <li>Profil
                <ul>
                    <li><span>Prénom: </span><?= $client->get_prenom(); ?></li>
                    <li><span>Nom: </span><?= $client->get_nom(); ?></li>
                    <li><span>Courriel: </span><?= $client->get_courriel(); ?></li>
                    <li><span>Mot de passe: </span><?= $client->get_mdp(); ?></li>
                </ul>
            </li>
            <li>Coordonnées
                <ul>
                    <li><span>Pays: </span><?= $client->get_pays(); ?></li>
                    <li><span>Adresse: </span><?= $client->get_adresse(); ?></li>
                    <li><span>Ville: </span><?= $client->get_ville(); ?></li>
                    <li><span>Province: </span><?= $client->get_province(); ?></li>
                    <li><span>Code postal: </span><?= $client->get_codePostal(); ?></li>
                    <li><span>Type Téléphone: </span><?= $client->get_typeTel(); ?></li>
                    <li><span>Téléphone: </span><?= $client->get_tel(); ?></li>
                </ul>
            </li>
            <li>Information conducteur
                <ul>
                    <li><span>Pays de délivrance: </span><?= $client->get_paysDelivrance(); ?></li>
                    <li><span>Date de naissance: </span><?= $client->get_dateNaissance(); ?></li>
                    <li><span>Numéro de permis: </span><?= $client->get_noPermis(); ?></li>
                    <li><span>Date d'expiration: </span><?= $client->get_dateExpiration(); ?></li>
                </ul>
            </li>
            <li>Préférence
                <ul>
                    <li><span>Infolettre: </span><?= ($client->get_infolettre() == "Oui" ? $client->get_infolettre() : "Non" ); ?></li>
                    <li><span>Modalité: </span><?= ($client->get_modalite()  == "Oui" ? $client->get_modalite() : "Non" ); ?></li>
                </ul>
            </li>
        </ul>

    <?php } elseif ($_REQUEST['action'] == "connexion"){ ?>
        <?php $client = unserialize($_SESSION['client']);?>
        <h1 class="center">Bienvenue <?php echo $client->get_nom(); ?> </h1>

    <?php } elseif ($_REQUEST['action'] == "logout"){ ?>
        <h1 class="center">Au revoir !</h1>

    <?php } elseif ($_REQUEST['action'] == "reservation") { 

        //Remplacer dans $_REQUEST la valeur de l'index "voiture" par l'objet Voiture.
        $_REQUEST["voiture"] = $voitures[$_REQUEST['voiture']];

        // Créer l'objet Réservation avec les données reçues
        $reservation = new Reservation($_REQUEST);
        $_SESSION['reservation'] = serialize($reservation);
        $client = unserialize($_SESSION['client']);


    ?>
        
        <h2 class="center">Merci pour votre confiance <?= $client->get_nom(); ?> !</h2>
        <h3 class="center">Votre réservation</h3>

        <ul class="traitement">
            <li><span>Date de début: </span><?= $reservation->get_datedebut();  ?></li>
            <li><span>Date de fin: </span><?= $reservation->get_datefin(); ?></li>
            <li><span>Age du locataire: </span><?= $reservation->get_ageLocataire(); ?> </li>
            <li><span>Voiture sélectionnée: </span>
                <?php
                    echo $_REQUEST["voiture"]->get_marque() . " " . $_REQUEST["voiture"]->get_modele() . " - " . $_REQUEST["voiture"]->get_categorie();
                ?>
            </li>
        </ul>

        
    <?php } ?>
<?php } ?>

<?php include_once("inc/footer.php"); ?>